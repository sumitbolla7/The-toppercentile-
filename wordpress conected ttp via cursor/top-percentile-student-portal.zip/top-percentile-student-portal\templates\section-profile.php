<?php
/**
 * Profile section.
 */

$avatar_url = $profile['avatar'] ? wp_get_attachment_image_url((int) $profile['avatar'], 'thumbnail') : '';
?>
<div class="tpsp-card">
    <h3><i class="fa-solid fa-id-card"></i> <?php esc_html_e('Student Profile', 'tpsp'); ?></h3>
    <form method="post" enctype="multipart/form-data" class="tpsp-form">
        <?php wp_nonce_field('tpsp_profile_update', 'tpsp_profile_nonce'); ?>
        <div class="tpsp-avatar-row">
            <img src="<?php echo esc_url($avatar_url ? $avatar_url : get_avatar_url($user->ID)); ?>" alt="<?php esc_attr_e('Avatar', 'tpsp'); ?>" class="tpsp-avatar" />
            <input type="file" name="avatar" accept="image/*" />
        </div>
        <div class="tpsp-form-grid">
            <input type="text" name="display_name" value="<?php echo esc_attr($user->display_name); ?>" placeholder="<?php esc_attr_e('Full Name', 'tpsp'); ?>" required />
            <input type="email" name="email" value="<?php echo esc_attr($user->user_email); ?>" placeholder="<?php esc_attr_e('Email', 'tpsp'); ?>" required />
            <input type="text" name="phone" value="<?php echo esc_attr($profile['phone']); ?>" placeholder="<?php esc_attr_e('Phone number', 'tpsp'); ?>" />
            <select name="gender">
                <option value=""><?php esc_html_e('Gender', 'tpsp'); ?></option>
                <option value="male" <?php selected($profile['gender'], 'male'); ?>><?php esc_html_e('Male', 'tpsp'); ?></option>
                <option value="female" <?php selected($profile['gender'], 'female'); ?>><?php esc_html_e('Female', 'tpsp'); ?></option>
                <option value="other" <?php selected($profile['gender'], 'other'); ?>><?php esc_html_e('Other', 'tpsp'); ?></option>
            </select>
            <input type="date" name="dob" value="<?php echo esc_attr($profile['dob']); ?>" />
            <input type="text" name="address" value="<?php echo esc_attr($profile['address']); ?>" placeholder="<?php esc_attr_e('Address', 'tpsp'); ?>" />
            <input type="text" name="city" value="<?php echo esc_attr($profile['city']); ?>" placeholder="<?php esc_attr_e('City', 'tpsp'); ?>" />
            <input type="text" name="state" value="<?php echo esc_attr($profile['state']); ?>" placeholder="<?php esc_attr_e('State', 'tpsp'); ?>" />
            <input type="text" name="country" value="<?php echo esc_attr($profile['country']); ?>" placeholder="<?php esc_attr_e('Country', 'tpsp'); ?>" />
            <input type="text" name="pincode" value="<?php echo esc_attr($profile['pincode']); ?>" placeholder="<?php esc_attr_e('Pincode', 'tpsp'); ?>" />
        </div>
        <button type="submit" name="tpsp_profile_submit" class="tpsp-btn"><?php esc_html_e('Update Profile', 'tpsp'); ?></button>
    </form>
</div>
