<?php
/**
 * Asset loader.
 */

if (!defined('ABSPATH')) {
    exit;
}

class TPSP_Assets {
    /**
     * Register hooks.
     *
     * @return void
     */
    public function hooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_action('wp_head', [$this, 'inject_exam_popup_kill_switch'], 1);
        add_action('wp_head', [$this, 'inject_order_received_access_strip'], 999);
        add_action('wp_footer', [$this, 'inject_cart_checkout_navigation_fix'], 40);
        add_action('wp_footer', [$this, 'inject_order_received_access_strip_js'], 999);
        add_action('wp_footer', [$this, 'inject_strip_orphan_single_product_notices'], 999);
    }

    /**
     * Hard-hide any success/access UI on order-received page.
     * This is intentionally broad to stop accidental access exposure.
     *
     * @return void
     */
    public function inject_order_received_access_strip() {
        $uri = isset($_SERVER['REQUEST_URI']) ? strtolower((string) wp_unslash($_SERVER['REQUEST_URI'])) : '';
        if (false === strpos($uri, '/checkout/order-received/')) {
            return;
        }
        ?>
        <style id="tpsp-order-received-access-strip">
            .ttp-success-box,
            .tpsp-thankyou,
            .ttp-access-btn,
            a[href*="tcyonline"],
            a[href*="erp_request.php"],
            [class*="access-course"],
            [id*="access-course"] {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        </style>
        <?php
    }

    /**
     * Remove leaked success/access nodes and block click-through links.
     *
     * @return void
     */
    public function inject_order_received_access_strip_js() {
        $uri = isset($_SERVER['REQUEST_URI']) ? strtolower((string) wp_unslash($_SERVER['REQUEST_URI'])) : '';
        if (false === strpos($uri, '/checkout/order-received/')) {
            return;
        }
        ?>
        <script id="tpsp-order-received-access-strip-js">
        (function () {
            function removeUnsafeNodes() {
                var selectors = [
                    '.ttp-success-box',
                    '.tpsp-thankyou',
                    '.ttp-access-btn',
                    'a[href*="tcyonline"]',
                    'a[href*="erp_request.php"]',
                    '[class*="access-course"]',
                    '[id*="access-course"]'
                ];
                selectors.forEach(function (s) {
                    document.querySelectorAll(s).forEach(function (el) { el.remove(); });
                });

                document.querySelectorAll('h1,h2,h3,p,div,button,a,span').forEach(function (el) {
                    var t = (el.textContent || '').toLowerCase();
                    if (
                        t.indexOf('payment successful') !== -1 ||
                        t.indexOf('login & access') !== -1 ||
                        t.indexOf('your course is now active') !== -1 ||
                        t.indexOf('enrollment confirmed') !== -1
                    ) {
                        el.remove();
                    }
                });
            }

            document.addEventListener('click', function (e) {
                var target = e.target && e.target.closest ? e.target.closest('.ttp-access-btn, a[href*="tcyonline"], a[href*="erp_request.php"], [class*="access-course"], [id*="access-course"]') : null;
                if (!target) return;
                e.preventDefault();
                e.stopPropagation();
                if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
                alert('Course access is available only after successful payment.');
            }, true);

            removeUnsafeNodes();
            setTimeout(removeUnsafeNodes, 300);
            setTimeout(removeUnsafeNodes, 1000);
            setTimeout(removeUnsafeNodes, 2200);
        })();
        </script>
        <?php
    }

    /**
     * Remove stray Woo notices above the summary card and keep WooCommerce URLs clickable.
     *
     * @return void
     */
    public function inject_strip_orphan_single_product_notices() {
        if (!function_exists('is_product') || !is_product()) {
            return;
        }
        ?>
        <script id="tpsp-strip-stray-product-notices">
        (function () {
            function outsideCard(el) {
                return !el.closest(".ttp-course-summary-card");
            }
            function prune() {
                document.querySelectorAll(".woocommerce-notices-wrapper").forEach(function (wrap) {
                    if (!outsideCard(wrap)) return;
                    wrap.remove();
                });
                document.querySelectorAll(".woocommerce-error, .woocommerce-message, .woocommerce-info").forEach(function (el) {
                    if (!outsideCard(el)) return;
                    el.remove();
                });
            }
            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", prune);
            } else {
                prune();
            }
            if (typeof jQuery !== "undefined") {
                jQuery(document.body).on("wc_fragment_refresh wc_fragments_loaded added_to_cart", prune);
            }
        })();
        </script>
        <?php
    }

    /**
     * Undo third-party handlers that kill checkout navigation (coupon plugins disabling .checkout-button).
     *
     * @return void
     */
    public function inject_cart_checkout_navigation_fix() {
        if (!function_exists('is_cart') || !is_cart()) {
            return;
        }
        $checkout_url = function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : '';
        ?>
        <script id="tpsp-cart-force-leave">
        (function () {
            var checkoutUrl = <?php echo wp_json_encode($checkout_url); ?>;
            if (!checkoutUrl) {
                return;
            }
            document.addEventListener(
                "click",
                function (e) {
                    var t = e.target;
                    if (!t || !t.closest) {
                        return;
                    }
                    var el = t.closest(
                        "#tpsp-proceed-checkout, a.tpsp-proceed-checkout, .wc-proceed-to-checkout a.checkout-button, a.checkout-button.wc-forward, a.wc-block-cart__submit-button, .wc-block-cart__submit-container a.checkout-button, button.tpsp-proceed-checkout-submit"
                    );
                    if (!el) {
                        return;
                    }
                    e.preventDefault();
                    if (typeof e.stopImmediatePropagation === "function") {
                        e.stopImmediatePropagation();
                    }
                    e.stopPropagation();
                    window.location.assign(checkoutUrl);
                },
                true
            );
        })();
        </script>
        <style id="tpsp-cart-proceed-always-clickable">
            .woocommerce-cart .wc-proceed-to-checkout .checkout-button,
            .woocommerce-cart .wc-proceed-to-checkout a.checkout-button,
            .woocommerce-cart a.checkout-button.button.alt,
            .woocommerce-cart a.tpsp-proceed-checkout,
            .woocommerce-cart #tpsp-proceed-checkout {
                pointer-events: auto !important;
                opacity: 1 !important;
                cursor: pointer !important;
            }
        </style>
        <script id="tpsp-unstick-checkout-navigation">
        (function ($) {
            var checkoutUrl = <?php echo wp_json_encode($checkout_url); ?>;
            var selectors = [
                "a.checkout-button",
                "button.checkout-button",
                ".checkout-button",
                ".woocommerce-checkout-review-order-table ~ .checkout .button",
                ".wc-proceed-to-checkout a",
                "a.tpsp-proceed-checkout",
                "#tpsp-proceed-checkout",
                ".wc-block-cart__submit-container a",
                ".wp-block-woocommerce-proceed-to-checkout-block a"
            ].join(", ");

            function fixNav() {
                $(selectors).each(function () {
                    var el = this;
                    el.removeAttribute("disabled");
                    el.removeAttribute("aria-disabled");
                    if (typeof $ !== "undefined" && $.fn.prop) {
                        $(el).prop("disabled", false).removeProp("disabled");
                    }
                    el.style.opacity = "";
                    el.style.pointerEvents = "";
                    el.style.cursor = "";
                    if (el.tagName && el.tagName.toLowerCase() === "a") {
                        var href = (el.getAttribute("href") || "").trim();
                        if ((!href || href === "#") && checkoutUrl) {
                            el.setAttribute("href", checkoutUrl);
                        }
                    }
                });
            }

            fixNav();

            if (typeof jQuery !== "undefined") {
                jQuery(document.body).on(
                    "updated_cart_totals updated_wc_div wc_fragments_loaded wc_fragment_refresh",
                    fixNav
                );
            }

            /* Smart Coupons and similar scripts can re-disable the button after AJAX; re-apply briefly after load. */
            var n = 0;
            var iv = setInterval(function () {
                fixNav();
                n++;
                if (n >= 25) {
                    clearInterval(iv);
                }
            }, 400);

            /* If theme/blocks left no working checkout control, show a fixed fallback link. */
            setTimeout(function () {
                if (!checkoutUrl) {
                    return;
                }
                if (document.getElementById("tpsp-floating-checkout")) {
                    return;
                }
                var candidates = document.querySelectorAll(
                    "a.checkout-button, a.tpsp-proceed-checkout, #tpsp-proceed-checkout, a.wc-block-cart__submit-button, .wc-block-cart__submit-container a"
                );
                var i, ok = false;
                for (i = 0; i < candidates.length; i++) {
                    var h = (candidates[i].getAttribute("href") || "").toLowerCase();
                    if (
                        h !== "#" &&
                        h.indexOf("javascript:") === -1 &&
                        (h.indexOf("checkout") !== -1 || h.indexOf("login") !== -1 || h.indexOf("redirect_to") !== -1)
                    ) {
                        ok = true;
                        break;
                    }
                }
                if (ok) {
                    return;
                }
                var a = document.createElement("a");
                a.id = "tpsp-floating-checkout";
                a.href = checkoutUrl;
                a.textContent = "Proceed to checkout";
                a.setAttribute("role", "button");
                a.style.cssText =
                    "position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:999999;" +
                    "padding:14px 28px;background:#f5c518;color:#111;font:800 15px system-ui,sans-serif;" +
                    "border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.4);text-decoration:none;";
                document.body.appendChild(a);
            }, 2200);
        })(typeof jQuery !== "undefined" ? jQuery : function () {});
        </script>
        <?php
    }

    /**
     * Enqueue frontend CSS and JS.
     *
     * @return void
     */
    public function enqueue_frontend_assets() {
        if (is_admin()) {
            return;
        }

        wp_enqueue_style(
            'tpsp-fontawesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css',
            [],
            '6.5.2'
        );

        wp_enqueue_style(
            'tpsp-frontend',
            TPSP_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            TPSP_VERSION
        );

        wp_enqueue_script(
            'tpsp-frontend',
            TPSP_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery'],
            TPSP_VERSION,
            true
        );

        $wc_ajax_url = function_exists('WC') && class_exists('WC_AJAX')
            ? WC_AJAX::get_endpoint('%%endpoint%%')
            : '';
        $checkout_url = function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : (function_exists('wc_get_page_permalink') ? wc_get_page_permalink('checkout') : home_url('/checkout/'));
        $cart_url = function_exists('wc_get_cart_url') ? wc_get_cart_url() : home_url('/cart/');

        $current_product_id = 0;
        $product_in_cart    = 0;
        if (is_product()) {
            $current_product_id = (int) get_queried_object_id();
            if ($current_product_id > 0 && function_exists('WC') && WC()->cart && WC()->cart->get_cart_contents_count() >= 1) {
                $cart_uid = WC()->cart->generate_cart_id($current_product_id, 0, [], []);
                $product_in_cart = WC()->cart->find_product_in_cart($cart_uid) ? 1 : 0;
            }
        }

        $purchased_product_ids    = [];
        $purchased_course_names   = [];
        $current_product_name     = '';
        if (is_product()) {
            $current_product_name = get_the_title(get_the_ID());
        }
        if (is_user_logged_in() && function_exists('wc_get_orders')) {
            $orders = wc_get_orders([
                'customer_id' => get_current_user_id(),
                'limit'       => -1,
                'status'      => array_keys(wc_get_order_statuses()),
            ]);

            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $product_id = (int) $item->get_product_id();
                    if ($product_id > 0) {
                        $purchased_product_ids[] = $product_id;
                    }
                    $item_name = trim((string) $item->get_name());
                    if ($item_name !== '') {
                        $purchased_course_names[] = $item_name;
                    }
                }
            }
            $purchased_product_ids = array_values(array_unique($purchased_product_ids));
            $purchased_course_names = array_values(array_unique($purchased_course_names));
        }

        wp_localize_script(
            'tpsp-frontend',
            'tpspData',
            [
                'ajaxUrl'         => admin_url('admin-ajax.php'),
                'loginUrl'        => function_exists('tpsp_get_login_page_url') ? tpsp_get_login_page_url() : home_url('/login/'),
                'myCoursesUrl'    => function_exists('tpsp_get_account_endpoint_url') ? tpsp_get_account_endpoint_url('my-courses') : (function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : home_url('/my-account/')),
                'checkoutUrl'     => $checkout_url,
                'cartUrl'        => $cart_url,
                'currentProductId' => $current_product_id,
                'productInCart'  => $product_in_cart,
                'isLoggedIn'      => is_user_logged_in() ? 1 : 0,
                'isSingleProduct' => is_product() ? 1 : 0,
                'isPurchasedCourse' => (is_user_logged_in() && is_product() && function_exists('wc_customer_bought_product')) ? (wc_customer_bought_product('', get_current_user_id(), get_the_ID()) ? 1 : 0) : 0,
                'purchasedProductIds' => $purchased_product_ids,
                'purchasedCourseNames' => $purchased_course_names,
                'currentProductName' => $current_product_name,
                'nonce'           => wp_create_nonce('tpsp_nonce'),
                'wcAjaxUrl'       => $wc_ajax_url,
                'spinnerText'     => __('Adding...', 'tpsp'),
                'successText'     => __('Added to cart successfully!', 'tpsp'),
                'verificationSent'=> __('Verification email sent.', 'tpsp'),
            ]
        );
    }

    /**
     * Hard-disable exam signup popup and force login/checkout redirects.
     *
     * @return void
     */
    public function inject_exam_popup_kill_switch() {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
        if (false === strpos($request_uri, '/exam/')) {
            return;
        }

        $checkout_url = function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : home_url('/checkout/');
        $login_url    = function_exists('tpsp_get_login_page_url') ? tpsp_get_login_page_url() : home_url('/login/');
        ?>
        <style id="tpsp-exam-popup-kill">
            #ttpSignupOverlay,
            .ttp-signup-overlay,
            .ttp-signup-modal,
            .ttp-modal-backdrop {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        </style>
        <script id="tpsp-exam-login-redirect-hardguard">
            (function () {
                var checkoutBase = <?php echo wp_json_encode($checkout_url); ?>;
                var loginBase = <?php echo wp_json_encode($login_url); ?>;

                function buildCheckoutUrl(pid) {
                    if (!pid) return checkoutBase;
                    var sep = checkoutBase.indexOf('?') === -1 ? '?' : '&';
                    return checkoutBase + sep + 'add-to-cart=' + encodeURIComponent(pid);
                }

                function enforce(e) {
                    var target = e.target && e.target.closest ? e.target.closest('.ttp-open-signup, .ttp-btn-enroll, .ttp-buy-now-btn') : null;
                    if (!target) return;
                    var pid = target.getAttribute('data-product-id') || '';
                    var checkoutUrl = buildCheckoutUrl(pid);
                    e.preventDefault();
                    e.stopPropagation();
                    if (typeof e.stopImmediatePropagation === 'function') {
                        e.stopImmediatePropagation();
                    }
                    var isLoggedIn = document.body && document.body.classList.contains('logged-in');
                    if (isLoggedIn) {
                        window.location.href = checkoutUrl;
                        return;
                    }
                    var sep = loginBase.indexOf('?') === -1 ? '?' : '&';
                    window.location.href = loginBase + sep + 'redirect_to=' + encodeURIComponent(checkoutUrl);
                }

                document.addEventListener('click', enforce, true);
            })();
        </script>
        <?php
    }
}
