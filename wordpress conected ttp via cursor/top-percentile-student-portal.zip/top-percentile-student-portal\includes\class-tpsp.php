<?php
/**
 * Main plugin orchestrator.
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-logger.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-assets.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-admin.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-user-registration-auto-approve.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-email-verification.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-dashboard.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-woocommerce.php';
require_once TPSP_PLUGIN_DIR . 'includes/class-tpsp-ajax.php';

class TPSP {
    /**
     * Plugin modules.
     *
     * @var array
     */
    private $modules = [];

    /**
     * Register plugin hooks.
     *
     * @return void
     */
    public function run() {
        $this->modules['assets']            = new TPSP_Assets();
        $this->modules['admin']             = new TPSP_Admin();
        $this->modules['ur_auto_approve']    = new TPSP_User_Registration_Auto_Approve();
        $this->modules['email_verification'] = new TPSP_Email_Verification();
        $this->modules['dashboard']         = new TPSP_Dashboard();
        $this->modules['woocommerce']       = new TPSP_WooCommerce();
        $this->modules['ajax']              = new TPSP_Ajax();

        foreach ($this->modules as $module) {
            if (method_exists($module, 'hooks')) {
                $module->hooks();
            }
        }

        add_action('tpsp_cleanup_expired_tokens', [$this, 'cleanup_expired_verification_tokens']);
    }

    /**
     * Cleanup expired verification tokens.
     *
     * @return void
     */
    public function cleanup_expired_verification_tokens() {
        global $wpdb;

        $meta_key_expiry = 'tpsp_email_verification_expiry';
        $now             = time();

        $user_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value <> '' AND CAST(meta_value AS UNSIGNED) < %d",
                $meta_key_expiry,
                $now
            )
        );

        if (empty($user_ids)) {
            return;
        }

        foreach ($user_ids as $user_id) {
            delete_user_meta((int) $user_id, 'tpsp_email_verification_token');
            delete_user_meta((int) $user_id, 'tpsp_email_verification_expiry');
        }
    }
}
