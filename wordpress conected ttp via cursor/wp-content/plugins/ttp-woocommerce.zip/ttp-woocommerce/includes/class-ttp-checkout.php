<?php
if (!defined('ABSPATH')) exit;

class TTP_Checkout {

    public function __construct() {
        add_action('woocommerce_payment_complete', [$this, 'trigger_tcy_registration']);
        add_action('woocommerce_order_status_completed', [$this, 'trigger_tcy_registration']);
        add_action('woocommerce_order_status_failed', [$this, 'revoke_unpaid_order_access']);
        add_action('woocommerce_order_status_cancelled', [$this, 'revoke_unpaid_order_access']);
        add_action('woocommerce_order_status_pending', [$this, 'revoke_unpaid_order_access']);
        add_action('woocommerce_order_status_refunded', [$this, 'revoke_unpaid_order_access']);
        add_action('woocommerce_thankyou', [$this, 'maybe_trigger_tcy_on_thankyou'], 5);
        /*
         * Block themes / some checkout layouts render the order-received page without firing
         * woocommerce_thankyou; this hook always runs after the order table on the thank-you view.
         */
        add_action('woocommerce_order_details_after_order_table', [$this, 'maybe_trigger_tcy_on_thankyou'], 5, 1);
        add_filter('woocommerce_checkout_fields', [$this, 'customize_checkout_fields']);
        add_action('template_redirect', [$this, 'nocache_order_received_page'], 0);
        add_action('template_redirect', [$this, 'maybe_redirect_thankyou_to_study_portal'], 3);
        add_action('wp_head', [$this, 'hide_legacy_thankyou_ttp_markup'], 0);
        add_action('wp_footer', [$this, 'remove_legacy_thankyou_ttp_markup_from_dom'], 1);

        // Allow other classes (e.g. AJAX TCY login) to reuse the same checkout instance without re-instantiating hooks.
        $GLOBALS['ttp_checkout'] = $this;
    }

    /**
     * Ensure TCY registration runs before thank-you UI when payment hooks already ran.
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public function maybe_trigger_tcy_on_thankyou($order_id_or_order) {
        if ($order_id_or_order instanceof WC_Order) {
            $order_id = (int) $order_id_or_order->get_id();
        } else {
            $order_id = absint($order_id_or_order);
        }
        if ($order_id <= 0) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        if (!function_exists('ttp_order_qualifies_for_tcy_actions') || !ttp_order_qualifies_for_tcy_actions($order)) {
            return;
        }
        if (!$this->order_contains_tcy_course($order)) {
            return;
        }
        $this->sync_tcy_if_missing_mapping($order_id);
    }

    /**
     * If order meta says "enrolled" but there is no usable TCY mapping row, clear stale meta and re-run registration.
     * Also used from AJAX magic-login so the first click can succeed even when thank-you hooks did not persist mapping.
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public function sync_tcy_if_missing_mapping($order_id) {
        $order_id = (int) $order_id;
        if ($order_id <= 0) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        if (!function_exists('ttp_order_qualifies_for_tcy_actions') || !ttp_order_qualifies_for_tcy_actions($order)) {
            return;
        }
        if (!$this->order_contains_tcy_course($order)) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ttp_order_mapping';
        $mapping = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE order_id = %d AND tcy_user_id IS NOT NULL AND tcy_user_id <> '' ORDER BY id DESC LIMIT 1",
                $order_id
            )
        );
        if ($mapping && (!function_exists('ttp_order_tcy_mapping_mismatch') || !ttp_order_tcy_mapping_mismatch($order, $mapping))) {
            return;
        }

        $order->delete_meta_data('_ttp_tcy_registered');
        $order->delete_meta_data('_tcy_enrolled');
        $order->delete_meta_data('_tcy_enrolled_at');
        $order->save();

        $this->trigger_tcy_registration($order_id);
    }

    public function trigger_tcy_registration($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        if (!function_exists('ttp_order_qualifies_for_tcy_actions') || !ttp_order_qualifies_for_tcy_actions($order)) {
            return;
        }
        if ($order->get_meta('_ttp_tcy_registered') || $order->get_meta('_tcy_enrolled') === 'yes') {
            if (!function_exists('ttp_order_tcy_mapping_needs_repair') || !ttp_order_tcy_mapping_needs_repair($order)) {
                return;
            }
            $order->delete_meta_data('_ttp_tcy_registered');
            $order->delete_meta_data('_tcy_enrolled');
            $order->delete_meta_data('_tcy_enrolled_at');
            $order->save();
        }

        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->prefix}ttp_order_mapping WHERE order_id = %d AND status = %s",
                (int) $order_id,
                'failed'
            )
        );

        $user_id = (int) $order->get_user_id();
        $student = null;
        if ($user_id > 0) {
            $student = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ttp_students WHERE wp_user_id = %d", $user_id
            ));
        }

        $api = new TTP_TCY_API();

        foreach ($order->get_items() as $item) {
            $product_id = (int) $item->get_product_id();
            if ($product_id < 1) {
                continue;
            }

            $tcy_ids = function_exists('ttp_get_tcy_ids_for_product')
                ? ttp_get_tcy_ids_for_product($product_id, true)
                : [
                    'course_id'   => (string) get_post_meta($product_id, '_ttp_tcy_course_id', true),
                    'category_id' => (string) get_post_meta($product_id, '_ttp_tcy_category_id', true),
                ];
            $tcy_course_id   = isset($tcy_ids['course_id']) ? (string) $tcy_ids['course_id'] : '';
            $tcy_category_id = isset($tcy_ids['category_id']) ? (string) $tcy_ids['category_id'] : '';

            if ($tcy_course_id === '') {
                continue;
            }

            // Check if student already has TCY account
            $existing_tcy_id = $student ? $student->tcy_user_id : null;
            $response        = null;

            if ($existing_tcy_id) {
                $response    = function_exists('ttp_tcy_ensure_course_on_account')
                    ? ttp_tcy_ensure_course_on_account($existing_tcy_id, $tcy_course_id, $tcy_category_id, (int) $order_id)
                    : $api->add_course($existing_tcy_id, $tcy_course_id, $tcy_category_id);
                $tcy_user_id = $existing_tcy_id;
            } else {
                $response = $api->register_student([
                    'full_name'   => $student ? $student->full_name : $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'email'       => $order->get_billing_email(),
                    'mobile'      => $order->get_billing_phone(),
                    'course_id'   => $tcy_course_id,
                    'category_id' => $tcy_category_id,
                    'order_id'    => $order_id,
                ]);
                $tcy_user_id = $this->extract_tcy_user_id($response);
                // TCY may return an existing user id without enrolling the purchased course — always add_course.
                if ($tcy_user_id !== '') {
                    $add_resp = function_exists('ttp_tcy_ensure_course_on_account')
                        ? ttp_tcy_ensure_course_on_account($tcy_user_id, $tcy_course_id, $tcy_category_id, (int) $order_id)
                        : $api->add_course($tcy_user_id, $tcy_course_id, $tcy_category_id);
                    if (function_exists('ttp_tcy_api_is_success') && ttp_tcy_api_is_success($add_resp)) {
                        $response = $add_resp;
                    }
                }
            }

            $api_ok     = function_exists('ttp_tcy_api_is_success') ? ttp_tcy_api_is_success($response) : (isset($response['success']) && (int) $response['success'] === 1);
            $map_status = 'failed';
            if ($existing_tcy_id && $tcy_user_id !== '') {
                // add_course may return 0 if already assigned — still allow magic login.
                $map_status = 'registered';
            } elseif ($api_ok && $tcy_user_id !== '') {
                $map_status = 'registered';
            } elseif ($tcy_user_id !== '') {
                // Have TCY user id (e.g. duplicate email) even when register success flag is ambiguous.
                $map_status = 'registered';
            }

            $wpdb->insert($wpdb->prefix . 'ttp_order_mapping', [
                'order_id'        => $order_id,
                'wp_user_id'      => $user_id,
                'tcy_user_id'     => $tcy_user_id,
                'tcy_course_id'   => $tcy_course_id,
                'tcy_category_id' => $tcy_category_id,
                'status'          => $map_status,
            ]);

            if ($tcy_user_id) {
                if ($user_id > 0) {
                    if ($student) {
                        $wpdb->update($wpdb->prefix . 'ttp_students', ['tcy_user_id' => $tcy_user_id], ['wp_user_id' => $user_id]);
                    } else {
                        $wpdb->insert($wpdb->prefix . 'ttp_students', [
                            'wp_user_id'  => $user_id,
                            'full_name'   => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                            'email'       => $order->get_billing_email(),
                            'mobile'      => $order->get_billing_phone(),
                            'username'    => $order->get_billing_email(),
                            'tcy_user_id' => $tcy_user_id,
                        ]);
                    }
                    update_user_meta($user_id, '_ttp_tcy_user_id', $tcy_user_id);
                }
            }
        }

        $registered_count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}ttp_order_mapping WHERE order_id = %d AND status = %s",
                (int) $order_id,
                'registered'
            )
        );
        if ($registered_count > 0) {
            $order->update_meta_data('_ttp_tcy_registered', true);
            $order->update_meta_data('_tcy_enrolled', 'yes');
            $order->update_meta_data('_tcy_enrolled_at', current_time('mysql'));
        }

        // After each order: ensure ALL paid courses are on this TCY account (not only the latest purchase).
        $sync_tcy_id = '';
        if ($student && !empty($student->tcy_user_id)) {
            $sync_tcy_id = (string) $student->tcy_user_id;
        } elseif ($user_id > 0) {
            $sync_tcy_id = (string) get_user_meta($user_id, '_ttp_tcy_user_id', true);
        }
        if ($sync_tcy_id === '' && $registered_count > 0) {
            $sync_tcy_id = (string) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT tcy_user_id FROM {$wpdb->prefix}ttp_order_mapping WHERE order_id = %d AND tcy_user_id <> '' ORDER BY id DESC LIMIT 1",
                    (int) $order_id
                )
            );
        }
        if ($sync_tcy_id !== '' && function_exists('ttp_tcy_sync_all_purchased_courses_for_user')) {
            ttp_tcy_sync_all_purchased_courses_for_user($sync_tcy_id, $user_id, $order->get_billing_email());
        }

        if (function_exists('ttp_tcy_collect_purchased_course_pairs')) {
            $pairs = ttp_tcy_collect_purchased_course_pairs($user_id, $order->get_billing_email());
            if (!empty($pairs)) {
                $order->update_meta_data('_ttp_tcy_enrolled_pairs', wp_json_encode(array_values($pairs)));
            }
        }

        $order->save();
    }

    /**
     * Thank-you HTML is per-order and changes when plugins update; full-page cache causes a 1-frame “old UI” flash.
     *
     * @return void
     */
    public function nocache_order_received_page() {
        if (!$this->is_order_received_thankyou_request()) {
            return;
        }
        if (headers_sent()) {
            return;
        }
        nocache_headers();
    }

    /**
     * Legacy TTP thank-you blocks (green box + party emoji) may still appear from full-page cache or old templates.
     * Hide immediately in head, then strip from DOM in footer so nothing flashes.
     *
     * @return void
     */
    public function hide_legacy_thankyou_ttp_markup() {
        if (!$this->is_order_received_thankyou_request()) {
            return;
        }
        ?>
        <style id="ttp-hide-legacy-thankyou-markup">
        .ttp-success-box,.ttp-purchase-thankyou{display:none!important;visibility:hidden!important;max-height:0!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important;opacity:0!important;pointer-events:none!important;}
        </style>
        <?php
    }

    /**
     * @return void
     */
    public function remove_legacy_thankyou_ttp_markup_from_dom() {
        if (!$this->is_order_received_thankyou_request()) {
            return;
        }
        ?>
        <script id="ttp-remove-legacy-thankyou-markup">
        (function(){
            function strip(){
                document.querySelectorAll('.ttp-success-box,.ttp-purchase-thankyou').forEach(function(n){n.remove();});
                document.querySelectorAll('div[style*="48px"]').forEach(function(n){
                    var t=(n.textContent||'').trim();
                    if(t.indexOf('🎉')!==-1&&t.length<16){n.remove();}
                });
            }
            strip();
            if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',strip);}
            setTimeout(strip,0);
        })();
        </script>
        <?php
    }

    /**
     * After a successful course purchase, send the customer straight to the TCY study portal (magic login).
     *
     * @return void
     */
    public function maybe_redirect_thankyou_to_study_portal() {
        if (!$this->is_order_received_thankyou_request()) {
            return;
        }
        if (isset($_GET['ttp_stay'])) {
            return;
        }
        if ('yes' !== get_option('ttp_redirect_thankyou_to_study', 'no')) {
            return;
        }
        $order_id = $this->get_order_id_from_order_received_request();
        if (!$order_id) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        if (!$this->customer_can_access_thankyou_order($order)) {
            return;
        }
        if (!apply_filters('ttp_redirect_thankyou_to_study_portal', true, $order)) {
            return;
        }
        if (!$this->order_contains_tcy_course($order)) {
            return;
        }
        if (!function_exists('ttp_order_qualifies_for_tcy_actions') || !ttp_order_qualifies_for_tcy_actions($order)) {
            return;
        }
        if (!$order->get_meta('_ttp_tcy_registered')) {
            $this->trigger_tcy_registration($order_id);
        }
        $target = $this->get_study_magic_login_redirect_url((int) $order_id);
        if (!is_string($target) || $target === '') {
            return;
        }
        if (!$this->is_permitted_magic_login_redirect_host($target)) {
            return;
        }
        if (function_exists('ttp_log_study_portal_redirect')) {
            global $wpdb;
            $tcy_id = '';
            if (isset($wpdb)) {
                $row = $wpdb->get_var($wpdb->prepare(
                    "SELECT tcy_user_id FROM {$wpdb->prefix}ttp_order_mapping WHERE order_id = %d ORDER BY id DESC LIMIT 1",
                    $order_id
                ));
                $tcy_id = is_string($row) ? $row : '';
            }
            ttp_log_study_portal_redirect('thankyou_redirect', $order_id, $target, $target, $tcy_id, 'Auto redirect after payment');
        }
        nocache_headers();
        // Host allowlisted in is_permitted_magic_login_redirect_host().
        wp_redirect($target, 302);
        exit;
    }

    /**
     * Only redirect browsers to known TCY / study hosts (magic-login URLs from our API).
     *
     * @param string $url Full URL.
     * @return bool
     */
    private function is_permitted_magic_login_redirect_host($url) {
        if (!is_string($url) || $url === '') {
            return false;
        }
        $parts = wp_parse_url($url);
        if (empty($parts['host']) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true)) {
            return false;
        }
        $host = strtolower($parts['host']);
        $allowed = [
            'study.thetoppercentile.co.in',
            'thetoppercentile.tcyonline.co.in',
            'www.thetoppercentile.tcyonline.co.in',
            'www.tcyonline.com',
            'tcyonline.com',
            'www.tcyonline.co.in',
            'tcyonline.co.in',
        ];
        $study = wp_parse_url((string) get_option('ttp_study_portal_base_url', 'https://study.thetoppercentile.co.in'));
        if (!empty($study['host'])) {
            $allowed[] = strtolower($study['host']);
        }
        $allowed = array_unique(array_map('strtolower', apply_filters('ttp_allowed_magic_login_redirect_hosts', $allowed)));
        if (in_array($host, $allowed, true)) {
            return true;
        }
        // Any TCY-managed host under tcyonline.com / tcyonline.co.in (white-label magic links).
        if (preg_match('/(?:^|\.)tcyonline\.(?:co\.in|com)$/i', $host)) {
            return (bool) apply_filters('ttp_allow_tcyonline_subdomain_redirects', true);
        }
        return false;
    }

    /**
     * True on classic or block checkout “order received” route (is_checkout() can be false with blocks).
     *
     * @return bool
     */
    private function is_order_received_thankyou_request() {
        if (function_exists('is_checkout') && is_checkout() && function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-received')) {
            return true;
        }
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
        return (bool) preg_match('#/checkout/order-received/\d+#i', $uri);
    }

    /**
     * Resolve order ID from query var or request URI (fallback when query vars are not set yet).
     *
     * @return int
     */
    private function get_order_id_from_order_received_request() {
        $order_id = absint(get_query_var('order-received'));
        if ($order_id) {
            return $order_id;
        }
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
        if (preg_match('#/checkout/order-received/(\d+)#i', $uri, $m)) {
            return absint($m[1]);
        }
        return 0;
    }

    /**
     * Valid order key in URL, or logged-in customer who owns the order (many stores omit ?key= for logged-in buyers).
     *
     * @param WC_Order $order Order.
     * @return bool
     */
    private function customer_can_access_thankyou_order($order) {
        if (!$order instanceof WC_Order) {
            return false;
        }
        $key = isset($_GET['key']) ? wc_clean(wp_unslash($_GET['key'])) : '';
        if ($key !== '' && $order->key_is_valid($key)) {
            return true;
        }
        if (is_user_logged_in()) {
            $customer_id = (int) $order->get_user_id();
            if ($customer_id > 0 && $customer_id === (int) get_current_user_id()) {
                return true;
            }
        }
        return (bool) apply_filters('ttp_thankyou_redirect_allow_without_key', false, $order);
    }

    /**
     * @param int $order_id Order ID.
     * @return string|false Absolute URL or false.
     */
    private function get_study_magic_login_redirect_url($order_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ttp_order_mapping';
        $mapping = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE order_id = %d AND tcy_user_id IS NOT NULL AND tcy_user_id <> '' ORDER BY (status = %s) DESC, id DESC LIMIT 1",
                $order_id,
                'registered'
            )
        );
        if (!$mapping || empty($mapping->tcy_user_id)) {
            return false;
        }
        $raw = '';
        if (!empty($mapping->login_link)) {
            $raw = $mapping->login_link;
        } else {
            $api = new TTP_TCY_API();
            $response = $api->login_student($mapping->tcy_user_id);
            $raw = function_exists('ttp_extract_login_url_from_tcy_response') ? ttp_extract_login_url_from_tcy_response($response) : (isset($response['link']) ? (string) $response['link'] : '');
            $login_ok = function_exists('ttp_tcy_api_is_success') ? ttp_tcy_api_is_success($response) : (isset($response['success']) && (int) $response['success'] === 1);
            if (!$login_ok || $raw === '') {
                return false;
            }
            $wpdb->update($table, ['login_link' => $raw], ['id' => $mapping->id], ['%s'], ['%d']);
        }
        $final = function_exists('ttp_rewrite_login_url_to_study_portal') ? ttp_rewrite_login_url_to_study_portal($raw) : $raw;
        if ($final !== $raw && is_string($final)) {
            $wpdb->update($table, ['login_link' => $final], ['id' => $mapping->id], ['%s'], ['%d']);
        }
        return $final;
    }

    /**
     * @param WC_Order $order Order.
     * @return bool
     */
    private function order_contains_tcy_course($order) {
        if (!$order instanceof WC_Order) {
            return false;
        }
        foreach ($order->get_items() as $item) {
            $pid = (int) $item->get_product_id();
            if (!$pid) {
                continue;
            }
            $src = function_exists('ttp_tcy_meta_source_product_id') ? ttp_tcy_meta_source_product_id($pid) : $pid;
            if (get_post_meta($src, '_ttp_tcy_course_id', true) || get_post_meta($pid, '_ttp_tcy_course_id', true)) {
                return true;
            }
        }
        return false;
    }

    /**
     * On failed/cancelled/pending/refunded orders, remove order-level TCY access artifacts.
     * This does not touch user-level mapping to avoid affecting previously paid orders.
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public function revoke_unpaid_order_access($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Do not strip TCY access while the order is still a successful checkout (covers ₹0 where is_paid() is false).
        if (function_exists('ttp_order_qualifies_for_tcy_actions') && ttp_order_qualifies_for_tcy_actions($order)) {
            return;
        }

        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->prefix}ttp_order_mapping WHERE order_id = %d",
                (int) $order_id
            )
        );

        $order->delete_meta_data('_ttp_tcy_registered');
        $order->delete_meta_data('_tcy_enrolled');
        $order->delete_meta_data('_tcy_enrolled_at');
        $order->save();
    }

    public function customize_checkout_fields($fields) {
        unset($fields['billing']['billing_company']);
        $fields['billing']['billing_address_2']['required'] = false;
        $fields['billing']['billing_phone']['required']     = true;
        return $fields;
    }

    private function extract_tcy_user_id($response) {
        if (function_exists('ttp_tcy_extract_register_user_id')) {
            $s = ttp_tcy_extract_register_user_id($response);
            return $s !== '' ? $s : null;
        }
        if (!is_array($response)) {
            return null;
        }

        $possible_keys = apply_filters(
            'ttp_tcy_register_user_id_keys',
            array('user_id', 'tcy_user_id', 'userid', 'student_id', 'erp_user_id', 'erp_userid', 'id')
        );
        foreach ($possible_keys as $key) {
            if (!empty($response[$key])) {
                return sanitize_text_field((string) $response[$key]);
            }
            if (isset($response['data']) && is_array($response['data']) && !empty($response['data'][$key])) {
                return sanitize_text_field((string) $response['data'][$key]);
            }
        }

        return null;
    }
}
