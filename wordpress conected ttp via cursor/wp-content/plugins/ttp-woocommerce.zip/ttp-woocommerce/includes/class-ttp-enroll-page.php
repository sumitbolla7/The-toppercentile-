<?php
/**
 * Renders [ttp_enroll_page] — exam / enrol landing (no signup modal; uses login + checkout flow).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TTP_Enroll_Page {

	public function __construct() {
		add_action( 'init', [ $this, 'register_shortcode' ], 999 );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_exam_landing_css' ], 20 );
	}

	/**
	 * Load enrol/exam CSS in &lt;head&gt; so layout + “hide duplicate title” apply before paint.
	 * Page slug is usually `exam` (/exam/).
	 *
	 * @return void
	 */
	public function maybe_enqueue_exam_landing_css() {
		$slugs = apply_filters( 'ttp_exam_landing_page_slugs', [ 'exam', 'enrol-now', 'enroll-now' ] );
		if ( ! is_array( $slugs ) || empty( $slugs ) ) {
			return;
		}
		if ( ! is_page( $slugs ) ) {
			return;
		}

		wp_enqueue_style(
			'ttp-enroll-page',
			TTP_URL . 'assets/css/ttp-enroll-page.css',
			[],
			TTP_VERSION
		);

		wp_add_inline_style(
			'ttp-enroll-page',
			'
			/* Hide duplicate theme/page-builder title (“Enrol Now”) above the hero shortcode */
			body.page-slug-exam article.type-page > header.entry-header,
			body.page-slug-exam .site-content article > header.entry-header:first-of-type,
			body.page-slug-exam .content-area article > header.entry-header:first-of-type,
			body.page-slug-exam #primary article > header.entry-header:first-of-type,
			body.page-slug-exam .elementor-location-archive header.entry-header,
			body.page-slug-exam .elementor-widget-theme-post-title .elementor-heading-title,
			body.page-slug-enrol-now article.type-page > header.entry-header,
			body.page-slug-enrol-now .site-content article > header.entry-header:first-of-type {
				display: none !important;
			}
			body.page-slug-exam .elementor-widget-theme-post-title,
			body.page-slug-enrol-now .elementor-widget-theme-post-title {
				display: none !important;
			}
			'
		);
	}

	public function register_shortcode() {
		add_shortcode( 'ttp_enroll_page', [ $this, 'render_shortcode' ] );
	}

	/**
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return '';
		}

		wp_enqueue_style(
			'ttp-enroll-page',
			TTP_URL . 'assets/css/ttp-enroll-page.css',
			[],
			TTP_VERSION
		);

		// Inline fallbacks: Elementor / theme often override enqueued CSS — mobile-first grid (do not force 3 cols on phones).
		wp_add_inline_style(
			'ttp-enroll-page',
			'
			body .ttp-enroll-page.ttp-enroll-page--light{background:#f4f6fb!important;color:#1a1a2e!important;box-sizing:border-box!important;}
			@media(min-width:783px){
			body .elementor-widget-shortcode .ttp-enroll-page.ttp-enroll-page--bleed-x{padding-left:clamp(16px,3.5vw,48px)!important;padding-right:clamp(16px,3.5vw,48px)!important;max-width:100vw!important;width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important;}
			body .elementor-widget-shortcode>.elementor-widget-container,
			body .elementor-widget-shortcode .elementor-widget-wrap{overflow:visible!important;}
			}
			body .ttp-enroll-page .ttp-plans-tier--premium,
			body .ttp-enroll-page .ttp-plans-tier--compact{display:grid!important;align-items:stretch!important;gap:clamp(18px,3vw,32px)!important;}
			@media(max-width:767px){
			body .ttp-enroll-page .ttp-plans-tier--premium,
			body .ttp-enroll-page .ttp-plans-tier--compact,
			body .ttp-enroll-page .ttp-plans-grid{grid-template-columns:1fr!important;}
			}
			@media(min-width:768px) and (max-width:991px){
			body .ttp-enroll-page .ttp-plans-tier--premium{grid-template-columns:repeat(2,minmax(0,1fr))!important;}
			body .ttp-enroll-page .ttp-plans-tier--compact{grid-template-columns:repeat(2,minmax(0,1fr))!important;}
			}
			@media(min-width:992px){
			body .ttp-enroll-page .ttp-plans-tier--premium{grid-template-columns:repeat(3,minmax(0,1fr))!important;}
			body .ttp-enroll-page .ttp-plans-tier--compact{grid-template-columns:repeat(2,minmax(0,1fr))!important;}
			}
			body .ttp-enroll-page .ttp-plan-card--tier-premium,body .ttp-enroll-page .ttp-plan-card--tier-compact{
				background:#fff!important;border:1px solid #e5e7eb!important;color:#1f2937!important;
				box-shadow:0 12px 40px rgba(26,26,46,.08)!important;
				display:flex!important;flex-direction:column!important;align-self:stretch!important;margin-top:0!important;
			}
			body .ttp-enroll-page .ttp-plan-card__header-row{position:relative!important;min-height:2.25rem!important;margin-top:0!important;}
			body .ttp-enroll-page .ttp-plan-ribbon{position:absolute!important;top:0!important;right:0!important;z-index:2!important;margin:0!important;}
			body .ttp-enroll-page .ttp-plan-card__title{color:#b45309!important;}
			body .ttp-enroll-page .ttp-plan-fgrid-text{color:#374151!important;}
			body .ttp-enroll-page .ttp-hero-eyebrow--hidden{display:none!important;}
			body .ttp-enroll-page *{box-sizing:border-box;}
			.elementor-widget-shortcode .ttp-enroll-page{width:100%!important;max-width:min(1920px,100%)!important;}
			body .ttp-enroll-page .ttp-plan-card--tier-premium .ttp-plan-price-strip,
			body .ttp-enroll-page .ttp-plan-card--tier-compact .ttp-plan-price-strip{grid-template-columns:1fr!important;justify-items:start!important;}
			body .ttp-enroll-page .ttp-plan-pstrip-current{color:#111!important;}
			body .ttp-enroll-page .ttp-plan-pstrip-was{color:#6b7280!important;}
			body .ttp-enroll-page .ttp-plan-rule{border-top-color:#e5e7eb!important;}
			body .ttp-enroll-page .ttp-plan-card__foot{border-top-color:#e5e7eb!important;background:#fafafa!important;}
			'
		);

		ob_start();
		require TTP_DIR . 'templates/enroll-page.php';
		return ob_get_clean();
	}
}
