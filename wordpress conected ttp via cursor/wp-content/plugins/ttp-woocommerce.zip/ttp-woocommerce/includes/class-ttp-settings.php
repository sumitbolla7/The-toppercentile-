<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TTP_Settings {

    public function __construct() {
        add_action( 'admin_menu',  [ $this, 'add_menu' ] );
        add_action( 'admin_init',  [ $this, 'register_settings' ] );
        add_action( 'wp_ajax_ttp_test_connection', [ $this, 'ajax_test' ] );
    }

    public function add_menu() {
        add_menu_page( 'TTP Dashboard', 'TTP Dashboard', 'manage_options', 'ttp-dashboard', [ $this, 'dashboard' ], 'dashicons-welcome-learn-more', 56 );
        add_submenu_page( 'ttp-dashboard', 'API Settings', 'API Settings', 'manage_options', 'ttp-settings', [ $this, 'settings_page' ] );
        add_submenu_page( 'ttp-dashboard', 'API Logs',     'API Logs',     'manage_options', 'ttp-api-logs', [ $this, 'logs_page' ] );
        add_submenu_page( 'ttp-dashboard', 'Study Redirect Logs', 'Study Redirect Logs', 'manage_options', 'ttp-study-redirect-logs', [ $this, 'study_redirect_logs_page' ] );
        add_submenu_page( 'ttp-dashboard', 'Students',     'Students',     'manage_options', 'ttp-students', [ $this, 'students_page' ] );
        add_submenu_page( 'ttp-dashboard', 'TCY Courses',  'TCY Courses',  'manage_options', 'ttp-courses',  [ $this, 'courses_page' ] );
        add_submenu_page( 'ttp-dashboard', 'MBA CET 2027 Catalog', 'MBA CET 2027 Catalog', 'manage_options', 'ttp-course-catalog', [ $this, 'catalog_seed_page' ] );
    }

    public function register_settings() {
        register_setting( 'ttp_settings_group', 'ttp_tcy_client_id',     [ 'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( 'ttp_settings_group', 'ttp_tcy_security_code', [ 'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( 'ttp_settings_group', 'ttp_study_portal_base_url', [ 'sanitize_callback' => 'esc_url_raw' ] );
        register_setting( 'ttp_settings_group', 'ttp_redirect_thankyou_to_study', [ 'sanitize_callback' => [ $this, 'sanitize_yes_no' ] ] );
    }

    /**
     * @param mixed $v Raw value.
     * @return string 'yes' or 'no'.
     */
    public function sanitize_yes_no( $v ) {
        return ( ! empty( $v ) && 'yes' === $v ) ? 'yes' : 'no';
    }

    public function dashboard() {
        global $wpdb;
        $students = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ttp_students" );
        $mapped   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ttp_students WHERE tcy_user_id IS NOT NULL" );
        $failed   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ttp_api_logs WHERE status='failed'" );
        $cid      = get_option( 'ttp_tcy_client_id', '' );
        ?>
        <div class="wrap">
            <h1>TTP Dashboard</h1>
            <?php if ( empty( $cid ) ): ?>
                <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:14px;margin:12px 0;">
                    ⚠️ TCY credentials not set. <a href="<?php echo admin_url('admin.php?page=ttp-settings'); ?>">Add them here →</a>
                </div>
            <?php else: ?>
                <div style="background:#d4edda;border:1px solid #c3e6cb;border-radius:8px;padding:14px;margin:12px 0;">
                    ✅ TCY Client ID: <strong><?php echo esc_html($cid); ?></strong>
                </div>
            <?php endif; ?>
            <div style="display:flex;gap:16px;flex-wrap:wrap;margin:20px 0;">
                <?php foreach ( [ ['Students', $students, '#1a56db'], ['TCY Mapped', $mapped, '#0a7a55'], ['API Failures', $failed, '#dc3545'] ] as [$label, $val, $color] ): ?>
                <div style="background:<?php echo $color; ?>;color:#fff;padding:20px 32px;border-radius:10px;text-align:center;">
                    <div style="font-size:30px;font-weight:700;"><?php echo $val; ?></div>
                    <div style="font-size:13px;margin-top:4px;"><?php echo $label; ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <p>
                <a href="<?php echo admin_url('admin.php?page=ttp-settings'); ?>" class="button button-primary">API Settings</a>
                <a href="<?php echo admin_url('admin.php?page=ttp-api-logs'); ?>"  class="button">API Logs</a>
                <a href="<?php echo admin_url('admin.php?page=ttp-students'); ?>"  class="button">Students</a>
                <a href="<?php echo admin_url('admin.php?page=ttp-courses'); ?>"   class="button">TCY Courses</a>
            </p>
        </div>
        <?php
    }

    public function settings_page() {
        if ( isset( $_POST['ttp_save'] ) && check_admin_referer( 'ttp_save_settings' ) ) {
            update_option( 'ttp_tcy_client_id',     sanitize_text_field( wp_unslash( $_POST['ttp_tcy_client_id'] ?? '' ) ) );
            update_option( 'ttp_tcy_security_code', sanitize_text_field( wp_unslash( $_POST['ttp_tcy_security_code'] ?? '' ) ) );
            update_option( 'ttp_study_portal_base_url', esc_url_raw( wp_unslash( $_POST['ttp_study_portal_base_url'] ?? '' ) ) ?: 'https://study.thetoppercentile.co.in' );
            update_option( 'ttp_redirect_thankyou_to_study', ! empty( $_POST['ttp_redirect_thankyou_to_study'] ) ? 'yes' : 'no' );
            echo '<div class="notice notice-success is-dismissible"><p>✅ Settings saved!</p></div>';
        }
        $cid = get_option( 'ttp_tcy_client_id', '' );
        $sec = get_option( 'ttp_tcy_security_code', '' );
        $study_base = get_option( 'ttp_study_portal_base_url', 'https://study.thetoppercentile.co.in' );
        $redirect_thankyou = get_option( 'ttp_redirect_thankyou_to_study', 'no' );
        ?>
        <div class="wrap"><h1>TCY API Settings</h1>
        <form method="post">
            <?php wp_nonce_field( 'ttp_save_settings' ); ?>
            <table class="form-table" style="max-width:720px;">
                <tr><th><label>TCY Client ID</label></th><td><input type="text" name="ttp_tcy_client_id" value="<?php echo esc_attr($cid); ?>" class="regular-text" placeholder="e.g. 7716"/></td></tr>
                <tr><th><label>TCY Security Code</label></th><td><input type="text" name="ttp_tcy_security_code" value="<?php echo esc_attr($sec); ?>" class="regular-text"/></td></tr>
                <tr>
                    <th scope="row"><label for="ttp_study_portal_base_url"><?php esc_html_e( 'Study portal URL', 'ttp-woocommerce' ); ?></label></th>
                    <td>
                        <input type="url" id="ttp_study_portal_base_url" name="ttp_study_portal_base_url" value="<?php echo esc_attr( $study_base ); ?>" class="large-text" placeholder="https://study.thetoppercentile.co.in"/>
                        <p class="description"><?php esc_html_e( 'White-label TCY host (no trailing slash). Magic login links from the API are rewritten to this domain.', 'ttp-woocommerce' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'After purchase', 'ttp-woocommerce' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="ttp_redirect_thankyou_to_study" value="yes" <?php checked( $redirect_thankyou, 'yes' ); ?>/>
                            <?php esc_html_e( 'Redirect order thank-you page to the study portal (auto login)', 'ttp-woocommerce' ); ?>
                        </label>
                        <p class="description"><?php esc_html_e( 'When enabled, the browser is sent straight to the study portal after a successful purchase (skips this thank-you page). Default is off so customers see “Thank you” and the study portal button here first.', 'ttp-woocommerce' ); ?></p>
                    </td>
                </tr>
            </table>
            <p><input type="submit" name="ttp_save" class="button button-primary button-large" value="Save Settings"/></p>
        </form>
        <?php if ( $cid ): ?>
        <hr/>
        <h2>Test Connection</h2>
        <button class="button button-secondary" id="ttp-test">Test TCY Connection</button>
        <div id="ttp-test-result" style="margin-top:14px;padding:14px;border-radius:8px;display:none;"></div>
        <script>
        document.getElementById('ttp-test').onclick = function(){
            var btn = this; btn.textContent = 'Testing...'; btn.disabled = true;
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body:'action=ttp_test_connection&nonce=<?php echo wp_create_nonce('ttp_nonce'); ?>'
            }).then(r=>r.json()).then(d=>{
                var el = document.getElementById('ttp-test-result'); el.style.display='block';
                if(d.success==1){
                    el.style.background='#d4edda'; el.style.border='1px solid #c3e6cb';
                    el.innerHTML='<strong style="color:green">✅ Connected! Courses found: '+(d.data?d.data.length:0)+'</strong>';
                } else {
                    el.style.background='#f8d7da'; el.style.border='1px solid #f5c6cb';
                    el.innerHTML='<strong style="color:red">❌ Failed</strong><pre>'+JSON.stringify(d,null,2)+'</pre>';
                }
                btn.textContent='Test TCY Connection'; btn.disabled=false;
            });
        };
        </script>
        <?php endif; ?>
        </div>
        <?php
    }

    public function study_redirect_logs_page() {
        if ( isset( $_POST['ttp_clear_study_redirect_logs'] ) && check_admin_referer( 'ttp_clear_study_redirect_logs' ) ) {
            if ( class_exists( 'TTP_Study_Redirect_Log', false ) ) {
                TTP_Study_Redirect_Log::clear();
            }
            echo '<div class="notice notice-success is-dismissible"><p>Study redirect logs cleared.</p></div>';
        }

        $max  = class_exists( 'TTP_Study_Redirect_Log', false ) ? TTP_Study_Redirect_Log::MAX_LOGS : 10;
        $logs = class_exists( 'TTP_Study_Redirect_Log', false ) ? TTP_Study_Redirect_Log::get_all() : array();
        ?>
        <div class="wrap">
            <h1>Study portal redirect logs (last <?php echo (int) $max; ?>)</h1>
            <p>Recorded when a customer is sent to the TCY study portal.</p>
            <form method="post" style="margin:12px 0;">
                <?php wp_nonce_field( 'ttp_clear_study_redirect_logs' ); ?>
                <input type="submit" name="ttp_clear_study_redirect_logs" class="button" value="Clear logs"/>
            </form>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Source</th>
                        <th>Order</th>
                        <th>User</th>
                        <th>TCY user ID</th>
                        <th>Final URL</th>
                        <th>Raw URL</th>
                        <th>Note</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $logs ) ) : ?>
                    <tr><td colspan="8">No redirects logged yet.</td></tr>
                <?php else : ?>
                    <?php foreach ( $logs as $row ) : ?>
                        <tr>
                            <td><?php echo esc_html( $row['time'] ?? '' ); ?></td>
                            <td><code><?php echo esc_html( $row['source'] ?? '' ); ?></code></td>
                            <td>
                                <?php
                                if ( ! empty( $row['order_id'] ) ) {
                                    $oid = (int) $row['order_id'];
                                    echo '<a href="' . esc_url( admin_url( 'post.php?post=' . $oid . '&action=edit' ) ) . '">#' . $oid . '</a>';
                                } else {
                                    echo '—';
                                }
                                ?>
                            </td>
                            <td><?php echo ! empty( $row['user_id'] ) ? (int) $row['user_id'] : '—'; ?></td>
                            <td><?php echo esc_html( $row['tcy_user_id'] ?? '' ); ?></td>
                            <td style="max-width:280px;word-break:break-all;"><a href="<?php echo esc_url( $row['final_url'] ?? '' ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $row['final_url'] ?? '' ); ?></a></td>
                            <td style="max-width:220px;word-break:break-all;"><small><?php echo esc_html( $row['raw_url'] ?? '' ); ?></small></td>
                            <td><?php echo esc_html( $row['note'] ?? '' ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function logs_page() {
        global $wpdb;
        $logs = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}ttp_api_logs ORDER BY created_at DESC LIMIT 100" );
        echo '<div class="wrap"><h1>API Logs</h1><table class="widefat"><thead><tr><th>ID</th><th>Action</th><th>Status</th><th>Order</th><th>Time</th></tr></thead><tbody>';
        foreach ( $logs as $l ) {
            $color = $l->status === 'success' ? 'green' : 'red';
            echo "<tr><td>{$l->id}</td><td>{$l->action}</td><td style='color:{$color};font-weight:600;'>{$l->status}</td><td>{$l->order_id}</td><td>{$l->created_at}</td></tr>";
        }
        echo '</tbody></table></div>';
    }

    public function students_page() {
        global $wpdb;
        $students = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}ttp_students ORDER BY created_at DESC LIMIT 100" );
        echo '<div class="wrap"><h1>Students</h1><table class="widefat"><thead><tr><th>Name</th><th>Email</th><th>Mobile</th><th>TCY ID</th><th>Registered</th></tr></thead><tbody>';
        foreach ( $students as $s ) {
            echo "<tr><td>{$s->full_name}</td><td>{$s->email}</td><td>{$s->mobile}</td><td>" . ( $s->tcy_user_id ?: '—' ) . "</td><td>{$s->created_at}</td></tr>";
        }
        echo '</tbody></table></div>';
    }

    public function courses_page() {
        echo '<div class="wrap"><h1>TCY Courses</h1>';
        if ( isset( $_POST['fetch_courses'] ) ) {
            $api    = new TTP_TCY_API();
            $result = $api->get_courses();
            echo '<pre style="background:#f1f1f1;padding:16px;border-radius:8px;overflow:auto;">' . esc_html( json_encode( $result, JSON_PRETTY_PRINT ) ) . '</pre>';
        } else {
            echo '<form method="post"><input type="submit" name="fetch_courses" class="button button-primary" value="Fetch Courses from TCY"/></form>';
        }
        echo '</div>';
    }

    /**
     * Create/update WooCommerce products + TCY IDs (editable under Products).
     */
    public function catalog_seed_page() {
        if ( ! class_exists( 'TTP_Catalog_Seed' ) ) {
            echo '<div class="wrap"><p>Catalog module not loaded.</p></div>';
            return;
        }

        if ( isset( $_POST['ttp_seed_catalog'] ) && check_admin_referer( 'ttp_seed_catalog' ) ) {
            $full = ! empty( $_POST['ttp_seed_full'] );
            $r     = TTP_Catalog_Seed::seed( $full );
            $fixed  = TTP_Catalog_Seed::repair_all_tcy_meta();
            $display = TTP_Catalog_Seed::repair_all_product_display_content();
            echo '<div class="notice notice-success is-dismissible"><p><strong>Done.</strong> '
                . sprintf(
                    /* translators: 1: created count, 2: updated count */
                    esc_html__( 'Created %1$d new products, updated %2$d. TCY Course / Product IDs are saved on each product (General → TCY).', 'ttp-woocommerce' ),
                    (int) $r['created'],
                    (int) $r['updated']
                );
            if ( ! empty( $fixed ) ) {
                echo ' ' . esc_html( sprintf( __( 'Corrected TCY mapping on %d product(s).', 'ttp-woocommerce' ), count( $fixed ) ) );
            }
            if ( ! empty( $display ) ) {
                echo ' ' . esc_html( sprintf( __( 'Refreshed unique course content on %d product(s).', 'ttp-woocommerce' ), (int) $display ) );
            }
            echo '</p></div>';
        }

        $defs = TTP_Catalog_Seed::get_definitions();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'MBA CET 2027 — WooCommerce catalog', 'ttp-woocommerce' ); ?></h1>
            <p><?php esc_html_e( 'Creates five virtual products, links each to TCY (course_id + product id sent as category_id in the API), and assigns category “MBA CET 2027”. Products stay fully editable under Products.', 'ttp-woocommerce' ); ?></p>
            <ul style="list-style:disc;padding-left:22px;max-width:920px;">
                <li><strong>CET NMAT SNAP Elite (with 1 on 1 Mentorship)</strong> — TCY Course <code>81196</code>, TCY Product <code>33604</code></li>
                <li><strong>CET NMAT SNAP Elite</strong> — TCY Course <code>81196</code>, TCY Product <code>33604</code></li>
                <li><strong>CET Elite (with 1 on 1 Mentorship)</strong> — TCY Course <code>81184</code>, TCY Product <code>33598</code></li>
                <li><strong>CET Elite</strong> — TCY Course <code>81184</code>, TCY Product <code>33598</code></li>
                <li><strong>CET Solo (Self Study)</strong> — TCY Course <code>81184</code>, TCY Product <code>33598</code></li>
            </ul>
            <p><strong><?php esc_html_e( 'Multiple purchases:', 'ttp-woocommerce' ); ?></strong>
                <?php esc_html_e( 'CET Elite, CET Solo, and CET Elite (Mentorship) all map to the same TCY product (81184 + 33598) — TCY will show one CET pack, not three separate courses. CET NMAT SNAP products use 81196 + 33604 — a different TCY product. A student who buys both CET Elite and NMAT SNAP should see two courses in TCY after sync (plugin v2.2.28+ calls add_course for every paid order).', 'ttp-woocommerce' ); ?>
            </p>
            <p><?php esc_html_e( 'Pack lines use “(12 Months)” at the end. After purchase, checkout still triggers TCY registration and the “Login & Access” flow.', 'ttp-woocommerce' ); ?></p>

            <form method="post" style="margin:20px 0;">
                <?php wp_nonce_field( 'ttp_seed_catalog' ); ?>
                <p>
                    <button type="submit" name="ttp_seed_catalog" class="button button-primary" value="1">
                        <?php esc_html_e( 'Sync TCY IDs only (safe)', 'ttp-woocommerce' ); ?>
                    </button>
                </p>
                <p>
                    <label>
                        <input type="checkbox" name="ttp_seed_full" value="1"/>
                        <?php esc_html_e( 'Full reset from catalog: overwrite titles, prices, descriptions, SKU from plugin definitions', 'ttp-woocommerce' ); ?>
                    </label>
                </p>
            </form>

            <h2><?php esc_html_e( 'Live mapping check (what the site will send to TCY)', 'ttp-woocommerce' ); ?></h2>
            <p><?php esc_html_e( 'If every row shows the same Course / Product IDs, run Sync above. NMAT rows must show 81196 + 33604; CET Solo / Elite rows must show 81184 + 33598.', 'ttp-woocommerce' ); ?></p>
            <table class="widefat striped" style="max-width:1100px;">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Plan', 'ttp-woocommerce' ); ?></th>
                        <th><?php esc_html_e( 'WC product', 'ttp-woocommerce' ); ?></th>
                        <th><?php esc_html_e( 'WC ID', 'ttp-woocommerce' ); ?></th>
                        <th><?php esc_html_e( 'SKU', 'ttp-woocommerce' ); ?></th>
                        <th><?php esc_html_e( 'TCY Course', 'ttp-woocommerce' ); ?></th>
                        <th><?php esc_html_e( 'TCY Product', 'ttp-woocommerce' ); ?></th>
                        <th><?php esc_html_e( 'Match', 'ttp-woocommerce' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php
                foreach ( $defs as $row ) :
                    $pid     = class_exists( 'TTP_Catalog_Seed' ) ? TTP_Catalog_Seed::get_product_id_for_definition( $row ) : 0;
                    $product = $pid ? wc_get_product( $pid ) : null;
                    $ids     = $product && class_exists( 'TTP_Catalog_Seed' ) ? TTP_Catalog_Seed::get_tcy_ids_for_product( $product ) : [ 'course_id' => '', 'product_id' => '' ];
                    $expect_c = (string) $row['tcy_course_id'];
                    $expect_p = (string) $row['tcy_product_id'];
                    $ok       = $ids['course_id'] === $expect_c && $ids['product_id'] === $expect_p;
                    ?>
                    <tr>
                        <td><?php echo esc_html( $row['name'] ); ?></td>
                        <td><?php echo $product ? esc_html( $product->get_name() ) : '<span style="color:#b45309;">' . esc_html__( 'Not found', 'ttp-woocommerce' ) . '</span>'; ?></td>
                        <td><?php echo $pid ? (int) $pid : '—'; ?></td>
                        <td><code><?php echo esc_html( $row['sku'] ); ?></code></td>
                        <td><code><?php echo esc_html( $ids['course_id'] ); ?></code></td>
                        <td><code><?php echo esc_html( $ids['product_id'] ); ?></code></td>
                        <td><?php echo $ok ? '✅' : '❌'; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h2><?php esc_html_e( 'Slugs (for reference)', 'ttp-woocommerce' ); ?></h2>
            <table class="widefat striped" style="max-width:720px;">
                <thead><tr><th><?php esc_html_e( 'Product', 'ttp-woocommerce' ); ?></th><th><?php esc_html_e( 'Slug', 'ttp-woocommerce' ); ?></th></tr></thead>
                <tbody>
                <?php foreach ( $defs as $row ) : ?>
                    <tr>
                        <td><?php echo esc_html( $row['name'] ); ?></td>
                        <td><code><?php echo esc_html( $row['slug'] ); ?></code></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function ajax_test() {
        check_ajax_referer( 'ttp_nonce', 'nonce' );
        $api = new TTP_TCY_API();
        wp_send_json( $api->test_connection() );
    }
}
