<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class TTP_Products {

    public function __construct() {
        // Admin: TCY meta fields on product edit page
        add_action( 'woocommerce_product_options_general_product_data', [ $this, 'add_tcy_fields' ] );
        add_action( 'woocommerce_process_product_meta',                 [ $this, 'save_tcy_fields' ] );

        // Front: show validity only (no timer, no icons) — once, before form
        add_action( 'woocommerce_before_add_to_cart_form', [ $this, 'show_validity' ], 10 );

        // Front: single Buy Now button
        add_action( 'woocommerce_after_add_to_cart_button', [ $this, 'buy_now_button' ], 10 );
    }

    /* ── Admin fields ── */
    public function add_tcy_fields() {
        global $post;
        echo '<div class="options_group"><h4 style="padding-left:12px;color:#e8540a;">TCY Platform Settings</h4>';
        woocommerce_wp_text_input( [ 'id' => '_ttp_tcy_course_id',   'label' => 'TCY Course ID',            'desc_tip' => true, 'description' => 'TCY course_id sent in register/add_course API (e.g. 81196).',    'value' => get_post_meta( $post->ID, '_ttp_tcy_course_id',   true ) ] );
        woocommerce_wp_text_input( [ 'id' => '_ttp_tcy_category_id', 'label' => 'TCY Product ID (category_id)', 'desc_tip' => true, 'description' => 'Must match TCY JSON "Product_id" (e.g. 33604) sent as category_id in register/add_course — NOT the MBA Entrance category_id (e.g. 100000). Stored as _ttp_tcy_category_id for backwards compatibility.', 'value' => get_post_meta( $post->ID, '_ttp_tcy_category_id', true ) ] );
        woocommerce_wp_text_input( [ 'id' => '_ttp_validity',        'label' => 'Course Validity',          'desc_tip' => true, 'description' => 'e.g. 12 Months',       'value' => get_post_meta( $post->ID, '_ttp_validity',        true ) ] );
        woocommerce_wp_text_input( [ 'id' => '_ttp_coupon_timer',    'label' => 'Discount Timer (minutes)', 'desc_tip' => true, 'description' => 'Countdown minutes',     'value' => get_post_meta( $post->ID, '_ttp_coupon_timer',    true ) ] );
        woocommerce_wp_text_input( [ 'id' => '_ttp_course_badge_label', 'label' => 'Course card badge (optional)', 'desc_tip' => true, 'description' => 'Short label shown under the title. Falls back to the first product category name.', 'value' => get_post_meta( $post->ID, '_ttp_course_badge_label', true ) ] );
        woocommerce_wp_textarea_input( [
            'id' => '_ttp_course_feature_grid',
            'label' => 'Course card feature grid',
            'description' => 'Up to four rows for the pricing card. Each line: Left title | Left description | Right title | Right description. Example: Live Classes | Daily live sessions | Mock Tests | 35+ CET mocks',
            'value' => get_post_meta( $post->ID, '_ttp_course_feature_grid', true ),
            'wrapper_class' => 'form-field-wide',
        ] );
        echo '</div>';
    }

    public function save_tcy_fields( $post_id ) {
        foreach ( [ '_ttp_tcy_course_id', '_ttp_tcy_category_id', '_ttp_validity', '_ttp_coupon_timer', '_ttp_course_badge_label' ] as $f ) {
            if ( isset( $_POST[ $f ] ) ) {
                update_post_meta( $post_id, $f, sanitize_text_field( wp_unslash( $_POST[ $f ] ) ) );
            }
        }
        if ( isset( $_POST['_ttp_course_feature_grid'] ) ) {
            update_post_meta( $post_id, '_ttp_course_feature_grid', sanitize_textarea_field( wp_unslash( $_POST['_ttp_course_feature_grid'] ) ) );
        }
    }

    /* ── Show course validity (no timer icon, no limited time text) ── */
    public function show_validity() {
        global $product;
        if ( ! $product ) return;

        $validity = get_post_meta( $product->get_id(), '_ttp_validity', true );
        $timer    = get_post_meta( $product->get_id(), '_ttp_coupon_timer', true );

        if ( $timer ) {
            echo '<div class="ttp-timer-wrap">'
               . '<strong>Limited Time Offer</strong> &mdash; Expires in: '
               . '<span class="ttp-countdown" data-minutes="' . esc_attr( $timer ) . '">--:--</span>'
               . '</div>';
        }

        if ( $validity ) {
            echo '<div class="ttp-validity-wrap">'
               . '<strong>Course Validity:</strong> ' . esc_html( $validity )
               . '</div>';
        }
    }

    /* ── Buy Now button ── */
    public function buy_now_button() {
        global $product;
        if ( ! $product ) return;
        echo '<a href="#" class="ttp-buy-now-btn" data-product-id="' . esc_attr( $product->get_id() ) . '">Buy Now</a>';
    }
}
