<?php
/**
 * Plan card — dark premium UI; tier: premium | compact | legacy.
 *
 * @package TTP_WooCommerce
 *
 * @var WC_Product $product
 * @var string     $badge
 * @var string     $discount_text
 * @var string     $features_html
 * @var array      $legacy_features
 * @var string     $ttp_enroll_card_tier Optional. premium|compact|legacy.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$ttp_card_tier = isset( $ttp_enroll_card_tier ) ? sanitize_key( (string) $ttp_enroll_card_tier ) : 'premium';
if ( '' === $ttp_card_tier ) {
	$ttp_card_tier = 'premium';
}

$ttp_is_popular = ! empty( $ttp_enroll_is_popular );

if ( ! isset( $legacy_features ) || ! is_array( $legacy_features ) ) {
	$legacy_features = [];
}

$url = get_permalink( $product->get_id() );

$grid_titles = [];
if ( isset( $features_html ) && is_string( $features_html ) && $features_html !== '' ) {
	if ( preg_match_all( '/<li[^>]*>(.*?)<\/li>/is', $features_html, $li_matches ) && ! empty( $li_matches[1] ) ) {
		foreach ( $li_matches[1] as $frag ) {
			$t = trim( wp_strip_all_tags( wp_specialchars_decode( $frag ) ) );
			if ( $t !== '' ) {
				$grid_titles[] = $t;
			}
		}
	}
}

if ( empty( $grid_titles ) && ! empty( $legacy_features ) ) {
	foreach ( $legacy_features as $f ) {
		$f = trim( wp_strip_all_tags( (string) $f ) );
		if ( $f !== '' ) {
			$grid_titles[] = $f;
		}
	}
}

// Pair features for two-column rows (this product only — slug resolved upstream).
$row_pairs = [];
$t_count     = count( $grid_titles );
for ( $i = 0; $i < $t_count; $i += 2 ) {
	$row_pairs[] = [
		isset( $grid_titles[ $i ] ) ? $grid_titles[ $i ] : '',
		isset( $grid_titles[ $i + 1 ] ) ? $grid_titles[ $i + 1 ] : '',
	];
}

// Smaller tier: cap visible pairs (balanced cards); full detail on PDP.
if ( 'compact' === $ttp_card_tier && count( $row_pairs ) > 5 ) {
	$row_pairs = array_slice( $row_pairs, 0, 5 );
}

$dlabel = isset( $discount_text ) ? trim( (string) $discount_text ) : '';

$card_classes = [
	'ttp-plan-card',
	'ttp-plan-card--tier-' . $ttp_card_tier,
];

if ( $ttp_is_popular ) {
	$card_classes[] = 'ttp-plan-card--popular';
}

?>
<div class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>">
	<div class="ttp-plan-card__inner">
		<div class="ttp-plan-card__header-row">
			<span class="ttp-plan-badge"><?php echo esc_html( $badge ); ?></span>
			<?php if ( $ttp_is_popular && 'legacy' !== $ttp_card_tier ) : ?>
				<span class="ttp-plan-ribbon"><?php esc_html_e( 'Most popular', 'ttp-woocommerce' ); ?></span>
			<?php endif; ?>
		</div>

		<h2 class="ttp-plan-card__title"><?php echo esc_html( $product->get_name() ); ?></h2>

		<hr class="ttp-plan-rule" />

		<div class="ttp-plan-price-strip">
			<span class="ttp-plan-pstrip-discount">
				<?php if ( '' !== $dlabel ) : ?>
					<span class="ttp-plan-pstrip-discount-badge"><?php echo esc_html( $dlabel ); ?></span>
				<?php else : ?>
					<span class="ttp-plan-pstrip-discount-muted"><?php esc_html_e( 'Best value', 'ttp-woocommerce' ); ?></span>
				<?php endif; ?>
			</span>
			<?php if ( 'legacy' === $ttp_card_tier ) : ?>
				<span class="ttp-plan-pstrip-current">
					<?php if ( $product->is_on_sale() ) : ?>
						<?php echo wp_kses_post( wc_price( $product->get_sale_price() ) ); ?>
					<?php else : ?>
						<?php echo wp_kses_post( wc_price( $product->get_price() ) ); ?>
					<?php endif; ?>
				</span>
				<span class="ttp-plan-pstrip-was">
					<?php if ( $product->is_on_sale() ) : ?>
						<del><?php echo wp_kses_post( wc_price( $product->get_regular_price() ) ); ?></del>
					<?php endif; ?>
				</span>
			<?php else : ?>
				<div class="ttp-plan-pstrip-row">
					<span class="ttp-plan-pstrip-current">
						<?php if ( $product->is_on_sale() ) : ?>
							<?php echo wp_kses_post( wc_price( $product->get_sale_price() ) ); ?>
						<?php else : ?>
							<?php echo wp_kses_post( wc_price( $product->get_price() ) ); ?>
						<?php endif; ?>
					</span>
					<?php if ( $product->is_on_sale() ) : ?>
						<span class="ttp-plan-pstrip-was">
							<del><?php echo wp_kses_post( wc_price( $product->get_regular_price() ) ); ?></del>
						</span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>

		<hr class="ttp-plan-rule" />

		<div class="ttp-plan-feature-grid">
			<?php
			foreach ( $row_pairs as $pair ) :
				if ( '' === trim( implode( '', $pair ) ) ) {
					continue;
				}
				?>
				<div class="ttp-plan-fgrid-row">
					<div class="ttp-plan-fgrid-cell">
						<?php if ( '' !== $pair[0] ) : ?>
							<span class="ttp-plan-fgrid-icon" aria-hidden="true"></span>
							<span class="ttp-plan-fgrid-text"><?php echo esc_html( $pair[0] ); ?></span>
						<?php endif; ?>
					</div>
					<div class="ttp-plan-fgrid-cell">
						<?php if ( '' !== $pair[1] ) : ?>
							<span class="ttp-plan-fgrid-icon" aria-hidden="true"></span>
							<span class="ttp-plan-fgrid-text"><?php echo esc_html( $pair[1] ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<hr class="ttp-plan-rule ttp-plan-rule--subtle" />
				<?php
			endforeach;
			?>
		</div>
	</div>

	<div class="ttp-plan-card__foot">
		<button
			type="button"
			class="ttp-btn-enroll ttp-buy-now-btn"
			data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"
		>
			<?php esc_html_e( 'Buy Now', 'ttp-woocommerce' ); ?>
		</button>
		<a href="<?php echo esc_url( $url ); ?>" class="ttp-btn-cart">
			<?php esc_html_e( 'View Details', 'ttp-woocommerce' ); ?>
		</a>
	</div>
</div>
