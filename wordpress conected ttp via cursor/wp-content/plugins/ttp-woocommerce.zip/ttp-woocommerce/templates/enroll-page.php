<?php
/**
 * Enroll landing markup (included by TTP_Enroll_Page shortcode).
 *
 * Prefers products in the MBA CET 2027 category; falls back to legacy plan config.
 *
 * @package TTP_WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve product ID from slug or fallback.
 *
 * @param string $slug Post name.
 * @param int    $fallback_id Product ID if slug missing.
 * @return int
 */
if ( ! function_exists( 'ttp_enroll_resolve_product_id' ) ) {
function ttp_enroll_resolve_product_id( $slug, $fallback_id ) {
	$slug = sanitize_title( $slug );
	if ( $slug ) {
		$q = new WP_Query(
			[
				'post_type'      => 'product',
				'name'           => $slug,
				'posts_per_page' => 1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			]
		);
		if ( ! empty( $q->posts[0] ) ) {
			return (int) $q->posts[0];
		}
	}

	return (int) $fallback_id;
}
}

/**
 * Badge label for enroll card from product slug.
 *
 * @param string $post_name Product post_name.
 * @return string
 */
if ( ! function_exists( 'ttp_enroll_badge_for_slug' ) ) {
function ttp_enroll_badge_for_slug( $post_name ) {
	$map = [
		'cet-nmat-snap-elite-with-1-on-1-mentorship' => 'ELITE+',
		'cet-nmat-snap-elite'                        => 'NMAT/SNAP',
		'cet-elite-with-1-on-1-mentorship'           => 'ELITE+',
		'cet-elite'                                  => 'CET',
		'cet-solo-self-study'                        => 'SOLO',
	];
	$post_name = (string) $post_name;

	return isset( $map[ $post_name ] ) ? $map[ $post_name ] : 'COURSE';
}
}

/**
 * @param WC_Product $product Product.
 * @return string e.g. "25% OFF" or empty.
 */
if ( ! function_exists( 'ttp_enroll_sale_badge_text' ) ) {
function ttp_enroll_sale_badge_text( $product ) {
	if ( ! $product instanceof WC_Product || ! $product->is_on_sale() ) {
		return '';
	}
	$reg  = (float) $product->get_regular_price();
	$sale = (float) $product->get_sale_price();
	if ( $reg <= 0 || $sale < 0 ) {
		return '';
	}
	$pct = (int) round( 100 * ( 1 - $sale / $reg ) );

	return $pct > 0 ? sprintf( '%d%% OFF', $pct ) : '';
}
}

/**
 * Feature list HTML for enroll cards: prefer catalog seed bullets by slug so each product
 * always matches its defined bullets (avoids stale or copied short descriptions in WooCommerce).
 *
 * @param WC_Product $product Product.
 * @return string Short description HTML (expected: ul/li).
 */
if ( ! function_exists( 'ttp_enroll_features_html_for_product' ) ) {
function ttp_enroll_features_html_for_product( $product ) {
	if ( class_exists( 'TTP_Catalog_Seed' ) ) {
		return TTP_Catalog_Seed::get_features_html_for_product( $product );
	}
	if ( $product instanceof WC_Product ) {
		return (string) $product->get_short_description();
	}

	return '';
}
}

/**
 * Build plan rows from WooCommerce category (MBA CET 2027 catalog).
 *
 * @param string $category_slug product_cat slug.
 * @return array<int, array{product: WC_Product, badge: string, discount_text: string, features_html: string}>
 */
if ( ! function_exists( 'ttp_enroll_rows_from_catalog_category' ) ) {
function ttp_enroll_rows_from_catalog_category( $category_slug ) {
	$category_slug = sanitize_title( $category_slug );
	if ( ! $category_slug ) {
		return [];
	}

	$q = new WP_Query(
		[
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
			'tax_query'      => [
				[
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $category_slug,
				],
			],
		]
	);

	$rows = [];
	foreach ( $q->posts as $post ) {
		if ( ! $post instanceof WP_Post ) {
			continue;
		}
		$product = wc_get_product( $post );
		if ( ! $product instanceof WC_Product ) {
			continue;
		}

		$rows[] = [
			'product'        => $product,
			'badge'          => ttp_enroll_badge_for_slug( $post->post_name ),
			'discount_text'  => ttp_enroll_sale_badge_text( $product ),
			'features_html'  => ttp_enroll_features_html_for_product( $product ),
		];
	}

	return apply_filters( 'ttp_enroll_catalog_rows', $rows, $category_slug );
}
}

/**
 * Build rows from plugin catalog slugs (works even if products are not in product_cat).
 *
 * @return array<int, array{product: WC_Product, badge: string, discount_text: string, features_html: string}>
 */
if ( ! function_exists( 'ttp_enroll_rows_from_seed_slugs' ) ) {
function ttp_enroll_rows_from_seed_slugs() {
	if ( ! class_exists( 'TTP_Catalog_Seed' ) ) {
		return [];
	}

	$rows = [];
	foreach ( TTP_Catalog_Seed::get_definitions() as $def ) {
		$slug = isset( $def['slug'] ) ? sanitize_title( $def['slug'] ) : '';
		if ( ! $slug ) {
			continue;
		}

		$product_id = class_exists( 'TTP_Catalog_Seed' ) ? TTP_Catalog_Seed::get_product_id_for_definition( $def ) : 0;
		if ( $product_id < 1 ) {
			$q = new WP_Query(
				[
					'post_type'      => 'product',
					'name'           => $slug,
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'no_found_rows'  => true,
				]
			);
			if ( empty( $q->posts[0] ) || ! $q->posts[0] instanceof WP_Post ) {
				continue;
			}
			$product_id = (int) $q->posts[0]->ID;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product instanceof WC_Product ) {
			continue;
		}

		$rows[] = [
			'product'       => $product,
			'badge'         => ttp_enroll_badge_for_slug( $product->get_slug() ? $product->get_slug() : $slug ),
			'discount_text' => ttp_enroll_sale_badge_text( $product ),
			'features_html' => ttp_enroll_features_html_for_product( $product ),
		];
	}

	return apply_filters( 'ttp_enroll_catalog_rows', $rows, 'seed-slugs' );
}
}

$legacy_plans = apply_filters(
	'ttp_enroll_page_plans',
	[
		[
			'product_slug'  => 'mhcet',
			'fallback_id'   => 17074,
			'badge'         => 'COURSE',
			'discount_text' => '90% OFF',
			'features'      => [
				'Full course access',
				'Practice tests',
				'Doubt-solving WhatsApp group',
			],
		],
		[
			'product_slug'  => 'cet-mh-test-series-with-mba-topic-wise-tests-batch-2',
			'fallback_id'   => 17075,
			'badge'         => 'TEST SERIES',
			'discount_text' => '70% OFF',
			'features'      => [
				'67 topic-wise concept builders',
				'196 practice tests',
				'16 TTP Turbo Mocks + 40 sectional tests',
				'MBA Topic-wise tests included',
				'Detailed performance analytics',
				'Doubt-solving WhatsApp group',
			],
		],
	]
);

$catalog_slug = apply_filters( 'ttp_enroll_catalog_category_slug', 'mba-cet-2027' );
// Slug list first: products often stay "Uncategorized" but still match catalog slugs.
$catalog_rows = ttp_enroll_rows_from_seed_slugs();
if ( empty( $catalog_rows ) ) {
	$catalog_rows = ttp_enroll_rows_from_catalog_category( $catalog_slug );
}
$use_catalog = ! empty( $catalog_rows );

/**
 * Premium top row vs compact bottom row (fixed slugs → correct product/feature pairing).
 *
 * @param array<int, array<string, mixed>> $rows Rows from seed or category.
 * @return array{tier_a: array, tier_b: array}
 */
$ttp_partition_enroll_rows = static function ( array $rows ): array {
	$by_slug = [];
	foreach ( $rows as $row ) {
		if ( empty( $row['product'] ) || ! $row['product'] instanceof WC_Product ) {
			continue;
		}
		$key = sanitize_title( $row['product']->get_slug() );
		if ( $key ) {
			$by_slug[ $key ] = $row;
		}
	}

	$a_slugs = [
		'cet-nmat-snap-elite-with-1-on-1-mentorship',
		'cet-nmat-snap-elite',
		'cet-elite-with-1-on-1-mentorship',
	];
	$b_slugs = [
		'cet-elite',
		'cet-solo-self-study',
	];

	$tier_a = [];
	foreach ( $a_slugs as $slug ) {
		if ( isset( $by_slug[ $slug ] ) ) {
			$tier_a[] = $by_slug[ $slug ];
			unset( $by_slug[ $slug ] );
		}
	}

	$tier_b = [];
	foreach ( $b_slugs as $slug ) {
		if ( isset( $by_slug[ $slug ] ) ) {
			$tier_b[] = $by_slug[ $slug ];
			unset( $by_slug[ $slug ] );
		}
	}

	return apply_filters(
		'ttp_enroll_partitioned_rows',
		[
			'tier_a' => $tier_a,
			'tier_b' => $tier_b,
		],
		$rows
	);
};
?>
<div class="ttp-enroll-page ttp-enroll-page--bleed-x ttp-enroll-page--light">
	<div class="ttp-enroll-hero">
		<span class="ttp-hero-eyebrow ttp-hero-eyebrow--hidden" aria-hidden="true"><?php esc_html_e( 'Enroll Now', 'ttp-woocommerce' ); ?></span>
		<h1>
			<?php
			echo wp_kses(
				__( 'Crack MAH MBA CET 2026<br>with <span>The Top Percentile</span>', 'ttp-woocommerce' ),
				[
					'br'   => [],
					'span' => [],
				]
			);
			?>
		</h1>
		<p><?php esc_html_e( 'Join 1000+ aspirants who\'ve cracked JBIMS, IIM-A, SPJIMR & NMIMS with our proven crash courses and test series.', 'ttp-woocommerce' ); ?></p>
		<div class="ttp-trust-badges">
			<span class="ttp-trust-badge"><span class="ttp-dot" aria-hidden="true"></span> <?php esc_html_e( 'Trusted by 1000+ aspirants', 'ttp-woocommerce' ); ?></span>
			<span class="ttp-trust-badge"><span class="ttp-dot" aria-hidden="true"></span> <?php esc_html_e( 'JBIMS alumni mentors', 'ttp-woocommerce' ); ?></span>
			<span class="ttp-trust-badge"><span class="ttp-dot" aria-hidden="true"></span> <?php esc_html_e( 'Live and recorded sessions', 'ttp-woocommerce' ); ?></span>
		</div>
	</div>

	<div class="ttp-plans-section">
		<h2 class="ttp-plans-title"><?php esc_html_e( 'Choose Your Plan', 'ttp-woocommerce' ); ?></h2>
		<p class="ttp-plans-subtitle"><?php esc_html_e( 'All plans include full access to our TCY learning portal.', 'ttp-woocommerce' ); ?></p>

		<?php if ( $use_catalog ) : ?>
			<?php
			$partitioned = $ttp_partition_enroll_rows( $catalog_rows );
			$tier_a_rows = $partitioned['tier_a'];
			$tier_b_rows = $partitioned['tier_b'];
			?>
			<div class="ttp-plans-wrap">
				<?php if ( ! empty( $tier_a_rows ) ) : ?>
					<div class="ttp-plans-tier ttp-plans-tier--premium" role="group" aria-label="<?php esc_attr_e( 'Premium programs', 'ttp-woocommerce' ); ?>">
						<?php
						foreach ( $tier_a_rows as $row ) :
							$product                = $row['product'];
							$badge                  = $row['badge'];
							$discount_text          = $row['discount_text'];
							$features_html           = $row['features_html'];
							$legacy_features        = [];
							$ttp_enroll_card_tier   = 'premium';
							$ttp_enroll_is_popular  = ( 'cet-nmat-snap-elite-with-1-on-1-mentorship' === sanitize_title( $product->get_slug() ) );

							include TTP_DIR . 'templates/enroll-page-part-card.php';
						endforeach;
						?>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $tier_b_rows ) ) : ?>
					<div class="ttp-plans-tier ttp-plans-tier--compact" role="group" aria-label="<?php esc_attr_e( 'Additional courses', 'ttp-woocommerce' ); ?>">
						<?php
						foreach ( $tier_b_rows as $row ) :
							$product                = $row['product'];
							$badge                  = $row['badge'];
							$discount_text           = $row['discount_text'];
							$features_html           = $row['features_html'];
							$legacy_features        = [];
							$ttp_enroll_card_tier   = 'compact';
							$ttp_enroll_is_popular  = false;

							include TTP_DIR . 'templates/enroll-page-part-card.php';
						endforeach;
						?>
					</div>
				<?php endif; ?>
			</div>
		<?php else : ?>
			<div class="ttp-plans-grid ttp-plans-grid--legacy">
				<?php foreach ( $legacy_plans as $plan ) : ?>
					<?php
					$pid     = ttp_enroll_resolve_product_id( $plan['product_slug'], $plan['fallback_id'] );
					$product = $pid ? wc_get_product( $pid ) : null;
					if ( ! $product ) {
						continue;
					}
					$badge                 = $plan['badge'];
					$discount_text         = $plan['discount_text'];
					$features_html          = '';
					$legacy_features       = $plan['features'];
					$ttp_enroll_card_tier  = 'legacy';
					$ttp_enroll_is_popular = false;

					include TTP_DIR . 'templates/enroll-page-part-card.php';
					?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
