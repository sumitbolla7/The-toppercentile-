<?php
/**
 * Plugin Name: TTP WooCommerce - TCY Integration
 * Plugin URI: https://thetoppercentile.co.in
 * Description: WooCommerce + TCY platform integration for Top Percentile.
 * Version: 2.2.29
 * Author: Top Percentile
 * Requires at least: 5.6
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'TTP_VERSION',    '2.2.29' );
define( 'TTP_DIR',        plugin_dir_path( __FILE__ ) );
define( 'TTP_URL',        plugin_dir_url( __FILE__ ) );

/**
 * Rewrite TCY magic-login URLs from the default white-label host to your public study domain
 * (e.g. thetoppercentile.tcyonline.co.in → study.thetoppercentile.co.in).
 *
 * @param string $url Absolute URL from TCY login API.
 * @return string
 */
/**
 * Login page URL; after login, user is sent to checkout (optionally with ?add-to-cart=).
 *
 * @param int $product_id WooCommerce product ID.
 * @return string
 */
function ttp_get_login_url_with_checkout_redirect( $product_id = 0 ) {
	$checkout = function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : home_url( '/checkout/' );
	$product_id = (int) $product_id;
	if ( $product_id > 0 ) {
		$checkout = add_query_arg( 'add-to-cart', $product_id, $checkout );
	}
	if ( function_exists( 'tpsp_get_login_redirect_url' ) ) {
		return tpsp_get_login_redirect_url( $checkout );
	}

	return add_query_arg( 'redirect_to', $checkout, home_url( '/login/' ) );
}

function ttp_rewrite_login_url_to_study_portal( $url ) {
    if ( ! is_string( $url ) || $url === '' ) {
        return $url;
    }
    if ( ! apply_filters( 'ttp_rewrite_study_portal_login_url', true, $url ) ) {
        return $url;
    }
    $target = rtrim( (string) get_option( 'ttp_study_portal_base_url', 'https://study.thetoppercentile.co.in' ), '/' );
    if ( $target === '' ) {
        return $url;
    }
    $parts = wp_parse_url( $url );
    if ( empty( $parts['host'] ) ) {
        return $url;
    }
    $target_parts = wp_parse_url( $target );
    $canonical_hosts = apply_filters(
        'ttp_tcy_login_url_hosts_to_rewrite',
        array(
            'thetoppercentile.tcyonline.co.in',
            'www.thetoppercentile.tcyonline.co.in',
        )
    );
    $host = strtolower( $parts['host'] );
    foreach ( (array) $canonical_hosts as $h ) {
        if ( strtolower( (string) $h ) === $host ) {
            $scheme   = ! empty( $target_parts['scheme'] ) ? $target_parts['scheme'] : 'https';
            $new_host = $target_parts['host'] ?? 'study.thetoppercentile.co.in';
            $path     = isset( $parts['path'] ) ? $parts['path'] : '';
            $query    = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
            $frag     = isset( $parts['fragment'] ) ? '#' . $parts['fragment'] : '';
            return $scheme . '://' . $new_host . $path . $query . $frag;
        }
    }
    if ( apply_filters( 'ttp_rewrite_all_tcyonline_magic_hosts', true ) && preg_match( '/\.tcyonline\.(?:co\.in|com)$/i', $host ) ) {
        $scheme   = ! empty( $target_parts['scheme'] ) ? $target_parts['scheme'] : 'https';
        $new_host = $target_parts['host'] ?? 'study.thetoppercentile.co.in';
        $path     = isset( $parts['path'] ) ? $parts['path'] : '';
        $query    = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
        $frag     = isset( $parts['fragment'] ) ? '#' . $parts['fragment'] : '';
        return $scheme . '://' . $new_host . $path . $query . $frag;
    }
    return $url;
}

/**
 * Successful checkout for TCY: paid / no balance due, and status is safe for enrollment.
 * Includes on-hold (often used after payment) — previously only processing/completed, which blocked many real orders.
 *
 * @param WC_Order|mixed $order Order.
 * @return bool
 */
function ttp_order_qualifies_for_tcy_actions( $order ) {
	if ( ! class_exists( 'WC_Order' ) || ! ( $order instanceof WC_Order ) ) {
		return false;
	}
	$status = $order->get_status();
	if ( in_array( $status, array( 'failed', 'cancelled', 'refunded', 'pending' ), true ) ) {
		return false;
	}
	if ( $order->needs_payment() ) {
		return false;
	}
	$allowed = apply_filters(
		'ttp_tcy_qualifying_order_statuses',
		array( 'processing', 'completed', 'on-hold' )
	);
	return in_array( $status, (array) $allowed, true );
}

/**
 * TCY JSON uses success as int 1, string "1", or boolean true depending on ERP version.
 *
 * @param array|mixed $response Decoded API body.
 * @return bool
 */
function ttp_tcy_api_is_success( $response ) {
	if ( ! is_array( $response ) || ! array_key_exists( 'success', $response ) ) {
		return false;
	}
	$s = $response['success'];
	if ( true === $s || 1 === $s || '1' === $s ) {
		return true;
	}
	if ( is_numeric( $s ) && (int) $s === 1 ) {
		return true;
	}
	return false;
}

/**
 * TCY register rejects empty or invalid mobiles. Normalize to 10 digits (India-style).
 *
 * @param string $raw Phone from checkout.
 * @return string
 */
function ttp_tcy_normalize_mobile_for_api( $raw ) {
	$digits = preg_replace( '/\D+/', '', (string) $raw );
	if ( strlen( $digits ) >= 10 ) {
		return substr( $digits, -10 );
	}
	if ( strlen( $digits ) > 0 ) {
		return str_pad( $digits, 10, '0', STR_PAD_RIGHT );
	}
	$fallback = (string) apply_filters( 'ttp_tcy_default_mobile_number', '9999999999' );
	return preg_match( '/^\d{10}$/', $fallback ) ? $fallback : '9999999999';
}

/**
 * Extract TCY user id from register (and similar) responses; structure varies by ERP build.
 *
 * @param array|mixed $response Decoded JSON.
 * @return string Non-empty id or ''.
 */
function ttp_tcy_extract_register_user_id( $response ) {
	if ( ! is_array( $response ) ) {
		return '';
	}
	$keys = apply_filters(
		'ttp_tcy_register_user_id_keys',
		array( 'user_id', 'tcy_user_id', 'userid', 'student_id', 'erp_user_id', 'erp_userid', 'UserId', 'USER_ID', 'id' )
	);
	foreach ( $keys as $key ) {
		if ( ! empty( $response[ $key ] ) || ( isset( $response[ $key ] ) && (string) $response[ $key ] === '0' ) ) {
			$v = (string) $response[ $key ];
			if ( $v !== '' ) {
				return sanitize_text_field( $v );
			}
		}
	}
	if ( ! empty( $response['data'] ) && is_array( $response['data'] ) ) {
		foreach ( $keys as $key ) {
			if ( ! empty( $response['data'][ $key ] ) || ( isset( $response['data'][ $key ] ) && (string) $response['data'][ $key ] === '0' ) ) {
				$v = (string) $response['data'][ $key ];
				if ( $v !== '' ) {
					return sanitize_text_field( $v );
				}
			}
		}
		if ( isset( $response['data'][0] ) && is_array( $response['data'][0] ) ) {
			foreach ( $keys as $key ) {
				if ( ! empty( $response['data'][0][ $key ] ) ) {
					return sanitize_text_field( (string) $response['data'][0][ $key ] );
				}
			}
		}
	}
	return '';
}

/**
 * Best-effort TCY error text for support (never includes security_code).
 *
 * @param array|mixed $decoded Decoded response_data JSON.
 * @return string
 */
function ttp_tcy_parse_api_error_from_response( $decoded ) {
	if ( ! is_array( $decoded ) ) {
		return '';
	}
	$blocks = array( $decoded );
	if ( ! empty( $decoded['data'] ) && is_array( $decoded['data'] ) ) {
		$blocks[] = $decoded['data'];
	}
	$text_keys = array( 'error', 'message', 'msg', 'ErrorMessage', 'error_message', 'err_msg' );
	$code_keys = array( 'code', 'error_code', 'errorcode', 'err_code', 'errorCode' );
	foreach ( $blocks as $block ) {
		if ( ! is_array( $block ) ) {
			continue;
		}
		foreach ( $text_keys as $k ) {
			if ( ! isset( $block[ $k ] ) || null === $block[ $k ] || '' === $block[ $k ] ) {
				continue;
			}
			if ( is_scalar( $block[ $k ] ) ) {
				$t = trim( wp_strip_all_tags( (string) $block[ $k ] ) );
				if ( $t !== '' ) {
					return sanitize_text_field( substr( $t, 0, 240 ) );
				}
			}
		}
		foreach ( $code_keys as $k ) {
			if ( ! isset( $block[ $k ] ) || null === $block[ $k ] || '' === $block[ $k ] ) {
				continue;
			}
			if ( is_scalar( $block[ $k ] ) ) {
				$c = trim( (string) $block[ $k ] );
				if ( $c !== '' ) {
					return sanitize_text_field( substr( 'TCY API: ' . $c, 0, 240 ) );
				}
			}
		}
	}
	return '';
}

/**
 * Last TCY API error for an order (register / login / add_course), newest first.
 *
 * @param int $order_id Order ID.
 * @return string
 */
function ttp_tcy_get_last_api_error_message_for_order( $order_id ) {
	global $wpdb;
	$order_id = (int) $order_id;
	if ( $order_id < 1 ) {
		return '';
	}
	$table = $wpdb->prefix . 'ttp_api_logs';
	if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
		return '';
	}
	$rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT action, response_data FROM {$table} WHERE order_id = %d AND action IN ('register','login','add_course') ORDER BY id DESC LIMIT 15",
			$order_id
		),
		ARRAY_A
	);
	if ( empty( $rows ) ) {
		return '';
	}
	foreach ( $rows as $row ) {
		$d = json_decode( $row['response_data'], true );
		if ( is_array( $d ) && function_exists( 'ttp_tcy_api_is_success' ) && ttp_tcy_api_is_success( $d ) ) {
			continue;
		}
		$err = ttp_tcy_parse_api_error_from_response( $d );
		if ( $err !== '' ) {
			return $err;
		}
	}
	return '';
}

/**
 * WooCommerce line item may be a variation: TCY meta is often stored on the parent product only.
 *
 * @param int $product_id Line product or variation id.
 * @return int Product id to read meta from.
 */
function ttp_tcy_meta_source_product_id( $product_id ) {
	$product_id = (int) $product_id;
	if ( $product_id < 1 || ! function_exists( 'wc_get_product' ) ) {
		return $product_id;
	}
	$p = wc_get_product( $product_id );
	if ( $p && $p->is_type( 'variation' ) ) {
		$parent = (int) $p->get_parent_id();
		return $parent > 0 ? $parent : $product_id;
	}
	return $product_id;
}

/**
 * Resolve TCY course_id + category_id (product id) for a WooCommerce product.
 * Prefers catalog seed by slug/SKU when stored meta does not match the canonical map.
 *
 * @param int  $product_id Line item product or variation ID.
 * @param bool $repair_meta When true, write corrected meta back to the product.
 * @return array{course_id: string, category_id: string, product_id: int, meta_src: int, repaired: bool}
 */
function ttp_get_tcy_ids_for_product( $product_id, $repair_meta = true ) {
	$product_id = (int) $product_id;
	$empty      = [
		'course_id'   => '',
		'category_id' => '',
		'product_id'  => $product_id,
		'meta_src'    => $product_id,
		'repaired'    => false,
		'plan_key'    => '',
	];
	if ( $product_id < 1 || ! function_exists( 'wc_get_product' ) ) {
		return $empty;
	}

	$product  = wc_get_product( $product_id );
	$meta_src = ttp_tcy_meta_source_product_id( $product_id );
	$course   = '';
	$category = '';
	$plan_key = '';
	$repaired = false;

	if ( $product && class_exists( 'TTP_Catalog_Seed' ) ) {
		$def = TTP_Catalog_Seed::get_definition_for_product( $product );
		if ( $def ) {
			$course   = (string) $def['tcy_course_id'];
			$category = (string) $def['tcy_product_id'];
			$plan_key = isset( $def['slug'] ) ? sanitize_title( (string) $def['slug'] ) : '';
			if ( $repair_meta ) {
				TTP_Catalog_Seed::apply_tcy_meta_from_definition( $product_id, $def );
				$repaired = true;
			}
		}
	}

	if ( $course === '' ) {
		$course = (string) get_post_meta( $meta_src, '_ttp_tcy_course_id', true );
		if ( '' === $course && $meta_src !== $product_id ) {
			$course = (string) get_post_meta( $product_id, '_ttp_tcy_course_id', true );
		}
	}
	if ( $category === '' ) {
		$category = (string) get_post_meta( $meta_src, '_ttp_tcy_category_id', true );
		if ( '' === $category && $meta_src !== $product_id ) {
			$category = (string) get_post_meta( $product_id, '_ttp_tcy_category_id', true );
		}
	}
	if ( $plan_key === '' ) {
		$plan_key = sanitize_title( (string) get_post_meta( $meta_src, '_ttp_tcy_plan_key', true ) );
	}

	return [
		'course_id'   => $course,
		'category_id' => $category,
		'product_id'  => $product_id,
		'meta_src'    => $meta_src,
		'repaired'    => $repaired,
		'plan_key'    => $plan_key,
	];
}

/**
 * Expected TCY mapping for the first TCY-linked line item on an order.
 *
 * @param WC_Order $order Order.
 * @return array{course_id: string, category_id: string, product_id: int}
 */
function ttp_get_tcy_ids_for_order( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return [ 'course_id' => '', 'category_id' => '', 'product_id' => 0 ];
	}
	foreach ( $order->get_items() as $item ) {
		$pid = (int) $item->get_product_id();
		if ( $pid < 1 ) {
			continue;
		}
		$ids = ttp_get_tcy_ids_for_product( $pid, true );
		if ( ! empty( $ids['course_id'] ) ) {
			return [
				'course_id'   => $ids['course_id'],
				'category_id' => $ids['category_id'],
				'product_id'  => $pid,
			];
		}
	}
	return [ 'course_id' => '', 'category_id' => '', 'product_id' => 0 ];
}

/**
 * True when stored order mapping does not match what the customer purchased.
 *
 * @param WC_Order   $order   Order.
 * @param object|null $mapping Row from ttp_order_mapping.
 * @return bool
 */
function ttp_order_tcy_mapping_mismatch( $order, $mapping ) {
	if ( ! $order instanceof WC_Order || ! $mapping ) {
		return false;
	}
	$expected = ttp_get_tcy_ids_for_order( $order );
	if ( '' === $expected['course_id'] ) {
		return false;
	}
	$got_course = isset( $mapping->tcy_course_id ) ? (string) $mapping->tcy_course_id : '';
	$got_cat    = isset( $mapping->tcy_category_id ) ? (string) $mapping->tcy_category_id : '';
	if ( $got_course === '' ) {
		return true;
	}
	if ( $got_course !== $expected['course_id'] ) {
		return true;
	}
	if ( $got_cat !== '' && $expected['category_id'] !== '' && $got_cat !== $expected['category_id'] ) {
		return true;
	}
	return false;
}

/**
 * Order marked enrolled but mapping missing/wrong — allow TCY registration to run again.
 *
 * @param WC_Order $order Order.
 * @return bool
 */
function ttp_order_tcy_mapping_needs_repair( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	global $wpdb;
	$table = $wpdb->prefix . 'ttp_order_mapping';
	$row   = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT * FROM {$table} WHERE order_id = %d AND tcy_user_id IS NOT NULL AND tcy_user_id <> '' ORDER BY id DESC LIMIT 1",
			(int) $order->get_id()
		)
	);
	if ( ! $row ) {
		return true;
	}
	return ttp_order_tcy_mapping_mismatch( $order, $row );
}

/**
 * Ensure the TCY account has the course from this order (idempotent add_course).
 *
 * @param string $tcy_user_id TCY user id.
 * @param string $course_id   TCY course id.
 * @param string $category_id TCY product id (category_id in API).
 * @param int    $order_id    WooCommerce order id for logging.
 * @return array API response.
 */
function ttp_tcy_ensure_course_on_account( $tcy_user_id, $course_id, $category_id, $order_id = 0 ) {
	$tcy_user_id   = sanitize_text_field( (string) $tcy_user_id );
	$course_id     = sanitize_text_field( (string) $course_id );
	$category_id   = sanitize_text_field( (string) $category_id );
	if ( $tcy_user_id === '' || $course_id === '' ) {
		return [ 'success' => 0, 'error' => 'Missing TCY user or course id.' ];
	}
	$api = new TTP_TCY_API();
	return $api->add_course( $tcy_user_id, $course_id, $category_id, $order_id > 0 ? $order_id : null );
}

/**
 * Collect unique TCY course + product pairs from all paid orders for a customer.
 *
 * @param int    $wp_user_id    WordPress user ID (0 for guest-only lookup).
 * @param string $billing_email Billing email (used when user_id is 0 or to include guest orders).
 * @return array<string, array{course_id: string, category_id: string, order_id: int}>
 */
function ttp_tcy_collect_purchased_course_pairs( $wp_user_id = 0, $billing_email = '' ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return [];
	}

	$wp_user_id    = (int) $wp_user_id;
	$billing_email = sanitize_email( (string) $billing_email );
	$statuses      = apply_filters( 'ttp_tcy_qualifying_order_statuses', [ 'processing', 'completed', 'on-hold' ] );
	$orders        = [];
	$seen_ids      = [];

	if ( $wp_user_id > 0 ) {
		$user_orders = wc_get_orders(
			[
				'customer_id' => $wp_user_id,
				'status'      => $statuses,
				'limit'       => -1,
				'orderby'     => 'date',
				'order'       => 'ASC',
			]
		);
		foreach ( $user_orders as $order ) {
			if ( $order instanceof WC_Order ) {
				$orders[]                           = $order;
				$seen_ids[ (int) $order->get_id() ] = true;
			}
		}
	}

	if ( $billing_email !== '' ) {
		$email_orders = wc_get_orders(
			[
				'billing_email' => $billing_email,
				'status'        => $statuses,
				'limit'         => -1,
				'orderby'       => 'date',
				'order'         => 'ASC',
			]
		);
		foreach ( $email_orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}
			$oid = (int) $order->get_id();
			if ( isset( $seen_ids[ $oid ] ) ) {
				continue;
			}
			$orders[]           = $order;
			$seen_ids[ $oid ] = true;
		}
	}

	$pairs = [];
	foreach ( $orders as $order ) {
		if ( ! function_exists( 'ttp_order_qualifies_for_tcy_actions' ) || ! ttp_order_qualifies_for_tcy_actions( $order ) ) {
			continue;
		}
		foreach ( $order->get_items() as $item ) {
			$product_id = (int) $item->get_product_id();
			if ( $product_id < 1 ) {
				continue;
			}
			$ids = function_exists( 'ttp_get_tcy_ids_for_product' )
				? ttp_get_tcy_ids_for_product( $product_id, true )
				: [
					'course_id'   => (string) get_post_meta( $product_id, '_ttp_tcy_course_id', true ),
					'category_id' => (string) get_post_meta( $product_id, '_ttp_tcy_category_id', true ),
				];
			$course_id = isset( $ids['course_id'] ) ? (string) $ids['course_id'] : '';
			if ( $course_id === '' ) {
				continue;
			}
			$category_id = isset( $ids['category_id'] ) ? (string) $ids['category_id'] : '';
			$key         = $course_id . '|' . $category_id;
			if ( ! isset( $pairs[ $key ] ) ) {
				$pairs[ $key ] = [
					'course_id'   => $course_id,
					'category_id' => $category_id,
					'order_id'    => (int) $order->get_id(),
				];
			}
		}
	}

	return $pairs;
}

/**
 * Call TCY add_course for every distinct course the customer has paid for (fixes multiple purchases → one course).
 *
 * @param string $tcy_user_id    TCY user id.
 * @param int    $wp_user_id      WP user id.
 * @param string $billing_email   Billing email.
 * @return int Number of add_course API calls made.
 */
function ttp_tcy_sync_all_purchased_courses_for_user( $tcy_user_id, $wp_user_id = 0, $billing_email = '' ) {
	$tcy_user_id = sanitize_text_field( (string) $tcy_user_id );
	if ( $tcy_user_id === '' ) {
		return 0;
	}

	$pairs = ttp_tcy_collect_purchased_course_pairs( (int) $wp_user_id, $billing_email );
	$count = 0;
	foreach ( $pairs as $pair ) {
		ttp_tcy_ensure_course_on_account(
			$tcy_user_id,
			$pair['course_id'],
			$pair['category_id'],
			(int) $pair['order_id']
		);
		++$count;
	}

	return $count;
}

/**
 * Parse TCY login API JSON for a redirect URL (field name varies by ERP version).
 *
 * @param array|mixed $response Decoded API response.
 * @return string
 */
function ttp_extract_login_url_from_tcy_response( $response ) {
    if ( ! is_array( $response ) ) {
        return '';
    }
    $keys = apply_filters( 'ttp_tcy_login_response_url_keys', array( 'link', 'login_link', 'url', 'redirect_url', 'redirect', 'magic_link', 'login_url', 'erp_link' ) );
    foreach ( $keys as $k ) {
        if ( ! empty( $response[ $k ] ) && is_string( $response[ $k ] ) ) {
            return $response[ $k ];
        }
    }
    if ( ! empty( $response['data'] ) && is_array( $response['data'] ) ) {
        foreach ( $keys as $k ) {
            if ( ! empty( $response['data'][ $k ] ) && is_string( $response['data'][ $k ] ) ) {
                return $response['data'][ $k ];
            }
        }
        if ( isset( $response['data'][0] ) && is_array( $response['data'][0] ) ) {
            foreach ( $keys as $k ) {
                if ( ! empty( $response['data'][0][ $k ] ) && is_string( $response['data'][0][ $k ] ) ) {
                    return $response['data'][0][ $k ];
                }
            }
        }
    }
    return '';
}

/* ── Autoload classes ── */
require_once TTP_DIR . 'includes/class-ttp-settings.php';
require_once TTP_DIR . 'includes/class-ttp-tcy-api.php';
require_once TTP_DIR . 'includes/class-ttp-student.php';
require_once TTP_DIR . 'includes/class-ttp-checkout.php';
require_once TTP_DIR . 'includes/class-ttp-products.php';
require_once TTP_DIR . 'includes/class-ttp-single-course.php';
require_once TTP_DIR . 'includes/class-ttp-enroll-page.php';
require_once TTP_DIR . 'includes/class-ttp-catalog-seed.php';
require_once TTP_DIR . 'includes/class-ttp-study-redirect-log.php';

/**
 * Record a study-portal redirect (keeps last 10 in WP admin → TTP Dashboard → Study Redirect Logs).
 *
 * @param string $source     e.g. ajax_button, thankyou_redirect, cached_link.
 * @param int    $order_id   WooCommerce order ID.
 * @param string $raw_url    URL from TCY before rewrite.
 * @param string $final_url  URL sent to the browser.
 * @param string $tcy_user_id TCY user id.
 * @param string $note       Optional note.
 * @return void
 */
function ttp_log_study_portal_redirect( $source, $order_id, $raw_url, $final_url, $tcy_user_id = '', $note = '' ) {
	if ( ! class_exists( 'TTP_Study_Redirect_Log', false ) ) {
		return;
	}
	TTP_Study_Redirect_Log::add(
		array(
			'source'      => sanitize_key( (string) $source ),
			'order_id'    => (int) $order_id,
			'user_id'     => get_current_user_id(),
			'tcy_user_id' => sanitize_text_field( (string) $tcy_user_id ),
			'raw_url'     => esc_url_raw( (string) $raw_url ),
			'final_url'   => esc_url_raw( (string) $final_url ),
			'note'        => sanitize_text_field( (string) $note ),
		)
	);
}
require_once TTP_DIR . 'includes/class-ttp-cart.php';
require_once TTP_DIR . 'admin/class-ttp-admin.php';

/* ── Activation: create DB tables + registration page ── */
register_activation_hook( __FILE__, 'ttp_activate' );
function ttp_activate() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ttp_students (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        wp_user_id bigint(20) NOT NULL,
        full_name varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        mobile varchar(20) NOT NULL,
        username varchar(100) NOT NULL,
        tcy_user_id varchar(100) DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $c;" );

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ttp_api_logs (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        order_id bigint(20) DEFAULT NULL,
        action varchar(100) NOT NULL,
        request_data longtext,
        response_data longtext,
        status varchar(20) DEFAULT 'pending',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $c;" );

    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ttp_order_mapping (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        order_id bigint(20) NOT NULL,
        wp_user_id bigint(20) NOT NULL,
        tcy_user_id varchar(100) DEFAULT NULL,
        tcy_course_id varchar(100) DEFAULT NULL,
        tcy_category_id varchar(100) DEFAULT NULL,
        login_link text DEFAULT NULL,
        status varchar(50) DEFAULT 'pending',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $c;" );

    if ( ! get_page_by_path( 'student-registration' ) ) {
        wp_insert_post( [
            'post_title'   => 'Student Registration',
            'post_name'    => 'student-registration',
            'post_content' => '[ttp_student_registration]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ] );
    }
}

/* ── Boot after WooCommerce loads ── */
add_action( 'plugins_loaded', function () {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }
    new TTP_Settings();
    new TTP_Student();
    new TTP_Checkout();
    new TTP_Products();
    new TTP_Single_Course();
    new TTP_Enroll_Page();
    new TTP_Cart();
    new TTP_Admin();

    if ( class_exists( 'TTP_Catalog_Seed' ) ) {
        $v = get_option( 'ttp_catalog_mba_cet_2027_version', '' );
        if ( $v !== TTP_Catalog_Seed::CATALOG_VERSION ) {
            TTP_Catalog_Seed::seed( false );
            TTP_Catalog_Seed::repair_all_tcy_meta();
            TTP_Catalog_Seed::repair_all_product_display_content();
        }
    }
}, 11 );

/* ── Frontend assets ── */
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style(  'ttp-style',  TTP_URL . 'assets/css/ttp-style.css',  [], TTP_VERSION );
    wp_enqueue_script( 'ttp-script', TTP_URL . 'assets/js/ttp-script.js', ['jquery'], TTP_VERSION, true );
    $checkout_url = function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : home_url( '/checkout/' );
    wp_localize_script( 'ttp-script', 'ttp_ajax', [
        'ajax_url'     => admin_url( 'admin-ajax.php' ),
        'nonce'        => wp_create_nonce( 'ttp_nonce' ),
        'login_url'    => function_exists( 'tpsp_get_login_page_url' ) ? tpsp_get_login_page_url() : home_url( '/login/' ),
        'checkout_url' => $checkout_url,
        'is_logged_in' => is_user_logged_in() ? 1 : 0,
    ] );
} );
