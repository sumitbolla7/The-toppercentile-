﻿=== Ultimate Member – User Profile, Registration, Login, Member Directory, Content Restriction & Membership Plugin ===
Author URI: https://ultimatemember.com/
Plugin URI: https://ultimatemember.com/
Contributors: ultimatemember, champsupertramp, nsinelnikov
Tags: community, member, membership, user-profile, user-registration
Requires PHP: 7.0
Requires at least: 6.2
Tested up to: 6.9
Stable tag: 2.11.4
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

Membership & community plugin with user profiles, registration & login, member directories, content restriction, user roles and much more.

== Description ==

= User Profile & Membership Plugin for WordPress =

The ultimate user profile & membership plugin for WordPress. The plugin makes it a breeze for users to sign-up and become members of your website. The plugin allows you to add beautiful user profiles to your site and is designed for creating advanced online communities and membership sites. Lightweight and highly extendible, Ultimate Member will enable you to create almost any type of site where users can join and become members with absolute ease.

= Features of the plugin include: =

* Front-end user profiles
* Front-end user registration
* Front-end user login
* Custom form fields
* Conditional logic for form fields
* Drag and drop form builder
* User account page
* Custom user roles
* Member directories
* User emails
* Content restriction
* Conditional nav menus
* Show author posts & comments on user profiles
* Developer friendly with dozens of actions and filters

Read about all of the plugin's features at [Ultimate Member](https://ultimatemember.com)

= Paid Extensions =

Ultimate Member has a range of extensions that allow you to extend the power of the plugin. You can purchase all of these extensions at a significant discount with one of our [paid plans](https://ultimatemember.com/pricing/) or you can purchase extensions individually.

* [Zapier](https://ultimatemember.com/extensions/zapier/) - Allow to integrate the Zapier popular apps with Ultimate Member
* [Stripe](https://ultimatemember.com/extensions/stripe/) - Sell paid memberships to access your website via Stripe subscriptions
* [User Notes](https://ultimatemember.com/extensions/user-notes/) - Allow users to create public and private notes from their profile
* [Profile Tabs](https://ultimatemember.com/extensions/profile-tabs/) - Allow to add the custom tabs to profiles
* [User Locations](https://ultimatemember.com/extensions/user-locations/) - Allow to display users on a map on the member directory page and allow users to add their location via their profile
* [Unsplash](https://ultimatemember.com/extensions/unsplash/) - Allow users to select a profile cover photo from [Unsplash](https://unsplash.com/) from their profile
* [User Bookmarks](https://ultimatemember.com/extensions/user-bookmarks/) - Allow users to bookmark content from your website
* [User Photos](https://ultimatemember.com/extensions/user-photos/) - Allow users to upload photos to their profile
* [Groups](https://ultimatemember.com/extensions/groups/) - Allow users to create and join groups around shared topics, interests etc.
* [Private Content](https://ultimatemember.com/extensions/private-content/) - Display private content to logged in users that only they can access
* [User Tags](https://ultimatemember.com/extensions/user-tags/) - Lets you add a user tag system to your website
* [Social Activity](https://ultimatemember.com/extensions/social-activity/) - Let users create public wall posts & see the activity of other users
* [WooCommerce](https://ultimatemember.com/extensions/woocommerce/) - Allow you to integrate WooCommerce with Ultimate Member
* [Private Messages](https://ultimatemember.com/extensions/private-messages/) - Add a private messaging system to your site & allow users to message each other
* [Followers](https://ultimatemember.com/extensions/followers/) - Allow users to follow each other on your site and protect their profile information
* [Real-time Notifications](https://ultimatemember.com/extensions/real-time-notifications/) - Add a notifications system to your site so users can receive real-time notifications
* [Social Login](https://ultimatemember.com/extensions/social-login/) - Let users register & login to your site via Facebook, Twitter, G+, LinkedIn, Instagram and Vkontakte (VK.com)
* [bbPress](https://ultimatemember.com/extensions/bbpress/) - With the bbPress extension you can beautifully integrate Ultimate Member with bbPress
* [MailChimp](https://ultimatemember.com/extensions/mailchimp/) - Allow users to subscribe to your MailChimp lists when they signup on your site and sync user meta to MailChimp
* [User Reviews](https://ultimatemember.com/extensions/user-reviews/) - Allow users to rate & review each other using a 5 star rate/review system
* [Verified Users](https://ultimatemember.com/extensions/verified-users/) - Add a user verification system to your site so user accounts can be verified
* [myCRED](https://ultimatemember.com/extensions/mycred/) - With the myCRED extension you can integrate Ultimate Member with the popular myCRED points management plugin
* [Notices](https://ultimatemember.com/extensions/notices/) - Alert users to important information using conditional notices
* [Profile Completeness](https://ultimatemember.com/extensions/profile-completeness/) - Encourage or force users to complete their profiles with the profile completeness extension
* [Friends](https://ultimatemember.com/extensions/friends/) - Allows users to become friends by sending & accepting/rejecting friend requests

= Free Extensions =

* [JobsBoardWP](https://ultimatemember.com/extensions/jobboardwp/) - This free extension integrates Ultimate Member with the job board plugin [JobBoardWP](https://wordpress.org/plugins/jobboardwp).
* [ForumWP](https://ultimatemember.com/extensions/forumwp/) - This free extension integrates Ultimate Member with the forum plugin [ForumWP](https://forumwpplugin.com).
* [Terms & Conditions](https://ultimatemember.com/extensions/terms-conditions/) - Add a terms and condition checkbox to your registration forms & require users to agree to your T&Cs before registering on your site.
* [Google reCAPTCHA](https://ultimatemember.com/extensions/google-recaptcha/) - Stop bots on your registration & login forms with Google reCAPTCHA
* [Online Users](https://ultimatemember.com/extensions/online-users/) - Display what users are online with this extension

= Theme =

Our official [theme](https://ultimatemember.com/theme/) is purpose built for websites that have logged in and out users. The [theme](https://ultimatemember.com/theme/) has deep integration with Ultimate Member plugin and the extensions, different header designs for logged-in/out users and works alongside the Beaver Builder and Elementor page builders.

= Our other plugins =

In addition to Ultimate Member, we also have two other plugins: [ForumWP](https://forumwpplugin.com/) and [JobBoardWP](https://wordpress.org/plugins/jobboardwp).

= ForumWP =

[ForumWP](https://forumwpplugin.com/) is a forum plugin which adds an online forum to your website, allowing users to create topics and write replies. Forums are a great way to build and grow an online community.

= JobBoardWP =

[JobBoardWP](https://wordpress.org/plugins/jobboardwp) is a job board plugin which adds a modern job board to your website. Display job listings and allow employers to submit and manage jobs all from the front-end.

= Development * Translations =

If you're a developer and would like to contribute to the source code of the plugin you can do so via our [GitHub Repository](https://github.com/ultimatemember/ultimatemember).

Want to add a new language to Ultimate Member? Great! You can contribute via [translate.wordpress.org](https://translate.wordpress.org/projects/wp-plugins/ultimate-member).

If you are a developer and you need to know the list of UM Hooks, make this via our [Hooks Documentation](https://docs.ultimatemember.com/article/1324-hooks-list) or [Hooks Documentation v2](https://ultimatemember.github.io/ultimatemember/hooks/).

If you are a developer and you need to know the structure of our code, make this via our [Documentation API](https://ultimatemember.github.io/ultimatemember/phpdoc/).

= Documentation & Support =

Got a problem or need help with Ultimate Member? Head over to our [documentation](http://docs.ultimatemember.com/) and perform a search of the knowledge base. If you can’t find a solution to your issue then you can create a topic on the [support forum](https://wordpress.org/support/plugin/ultimate-member).


== Installation ==

1. Activate the plugin
2. That's it. Go to Ultimate Member > Settings to customize plugin options
3. For more details, please visit the official [Documentation](http://docs.ultimatemember.com/) page.

== Frequently Asked Questions ==

= Do I need to know any coding to use this plugin? =

No, we have built Ultimate Member to be extremely easy to use and does not require you to manually build shortcodes or have any coding knowledge.

= Is Ultimate Member mobile responsive? =

Yes. Ultimate Member is designed to adapt nicely to any screen resolution. It includes specific designs for phones, tablets and desktops.

= Is Ultimate Member multi-site compatible? =

Yes. Ultimate Member works great on both single site and multi-site WordPress installs.

= Does the plugin work with any WordPress theme? =

Yes. Ultimate Member will work with any properly coded theme. However, some themes may cause conflicts with the plugin. If you find a styling issue with your theme please create a post in the community forum.

= Does the plugin work with caching plugins? =

The plugin works with popular caching plugins by automatically excluding Ultimate Member pages from being cached. This ensures other visitors to a page will not see the private information of another user. However, if you add features of Ultimate Member to other pages you have to exclude those pages from being cached through your cache plugin settings panel.

= Does Ultimate Member restrict access to wp-login.php when the plugin is active? =

The plugin does not restrict access to the wp-login.php page when active, so that our plugin does not interfere with the existing functionality of a website or other plugins that may utilise the default login page. If you wish to restrict access to the wp-login.php page you can use a plugin such as [WPS Hide Login](https://wordpress.org/plugins/wps-hide-login/) or another plugin that removes the ability to login via wp-login.php.

= Are Ultimate Member Login/Registration pages required? =

No, you do not need to use our plugin’s login or registration pages and can use another plugin or the default WordPress methods for user registration and login.

= Are additional PHP modules necessary for the plugin to work correctly? =

No specific extensions are needed. But we highly recommended keep active these PHP modules: `mbstring`, `json`, `dom`, `exif`, `gd`, `fileinfo`, `curl`, `iconv`. wp-admin > Tools > Site Health page has a summary about your installation and required modules. All major extensions are listed [here](https://make.wordpress.org/hosting/handbook/server-environment/#php-extensions).

== Screenshots ==

1. Screenshot 1
2. Screenshot 2
3. Screenshot 3
4. Screenshot 4
5. Screenshot 5
6. Screenshot 6
7. Screenshot 7
8. Screenshot 8
9. Screenshot 9
10. Screenshot 10
11. Screenshot 11
12. Screenshot 12

== Changelog ==

= Important: =

IMPORTANT: PLEASE UPDATE THE PLUGIN TO AT LEAST VERSION 2.6.7 IMMEDIATELY. VERSION 2.6.7 PATCHES SECURITY PRIVILEGE ESCALATION VULNERABILITY. PLEASE SEE [THIS ARTICLE](https://docs.ultimatemember.com/article/1866-security-incident-update-and-recommended-actions) FOR MORE INFORMATION

= 2.11.4 2026-04-30 =

**Enhancements**

* Added: Checking format of the 3rd-party registered custom fields. Avoid PHP errors related to the wrong format or unexpected attributes.

**Bugfixes**

* Fixed: Added uploader fields `accept` argument for set allowed mime-types in the upload dialog window. Updated 3.1.2 version of this library [hayageek/jquery-upload-file](https://github.com/hayageek/jquery-upload-file/). Don't use 4.0.11 version for now.
* Fixed: JS initialization of the empty uploader fields.
* Fixed: User Profile URLs in the User Profile form on the not-predefined pages placed via shortcode.

**Note: Cached and optimized/minified assets(JS/CSS) must be flushed/re-generated after the upgrade**

= 2.11.3 2026-03-26 =

**Enhancements**

* Added: UM > Settings > Advanced > APIs section for set available APIs settings.
* Added: GoogleMaps API setting when it's available.
* Added: Function `UM()->mail()->enabled_email()` for checking if the email notification is enabled by the user.
* Added: `color` type of sanitize settings saved in wp-admin.
* Added: Checking array type of submission data when `url` type of sanitize is used in wp-admin.
* Added: Enhance UM form sanitization filter with $form_data param. Added the $form_data parameter to the `um_sanitize_form_submission` filter.
* Added: Option for special character requirement for passwords. It's situated in "General > Users > Password requires special character" (based on @faisalahammad suggestions)
* Added: Filter hook `um_before_account_delete_text` for changing before delete account text by 3rd-party plugins. End-customers can use it for translations.
* Added: Filter hook `um_custom_{$message_key}` (`um_custom_pending_message`, `um_custom_checkmail_message`) for changing after-registration message based on the user status by 3rd-party plugins. End-customers can use it for translations.
* Added: Filter hook `um_convert_tags_blacklist_fields` For 3rd-party integrations to control the usermeta keys in `um_convert_tags()` function.
* Added: `.um-display-none` CSS utility + `umShow()/umHide()/umToggle()` jQuery helpers.
* Added: `um-notice` JS library.

**Bugfixes**

* Fixed: Security issue, CVE ID: CVE-2026-4248. Added blacklist filter for convert_tag replace placeholders function.
* Fixed: HTML sanitization logic for textarea-type custom fields with enabled HTML using setting.
* Fixed: WP editor formatting to prevent incorrect HTML entity conversion when using html-mode in the textarea-type custom fields. Applied and removed this filter dynamically to avoid interfering with other processes.
* Fixed: Dynamic string translation pattern and improve escaping. Replaced incorrect __('%s') pattern. (@faisalahammad)
* Fixed: `wp_die()` function triggering on the frontend actions. Added UM notice above the User Profile page. (based on @faisalahammad suggestions)
* Fixed: Password reset key handling for multiple users. Previously, the static reset key caused issues when handling password resets for multiple users simultaneously.
* Fixed: `um_trim_string()` function for using with UTF-8 symbols.
* Fixed: PHP Notice: Function WP_Scripts::add was called incorrectly.

**Templates Requiring Update**

* members.php
* message.php
* restricted-blog.php
* restricted-taxonomy.php

**Note: Cached and optimized/minified assets(JS/CSS) must be flushed/re-generated after the upgrade**

= 2.11.2 2026-02-10 =

**Enhancements**

* Added: Server-side validation when the Search Form is submitted.
* Added: Action hook `um_approve_user_on_email_confirmation` to natively approve the user after validating the email activation link.
* Added: JS filter wp.hook `um_member_directory_popstate_ignore` to stop window.pushSate in the member directory for 3rd-party integrations.

**Bugfixes**

* Fixed: Security issue, CVE ID: CVE-2025-15064. Deprecated the ability to use HTML inside the user description. It's still allowed to use only predefined 'user_description' tags in `wp_kses()`.
* Fixed: Security issue, CVE ID: CVE-2026-1404. Modified template item formatting to avoid using HTML characters in the filter values.
* Fixed: Profile photo dropdown menu position for screens smaller than 340px.
* Fixed: Display of the saved value of the "Privacy Options" > "Allowed roles" setting for the member directory.
* Fixed: Information in Site-Health about the registration form's `Template` and `Role` settings.
* Fixed: Information in Site-Health about the login and profile form's `Template` settings.

**Templates Requiring Update**

* members.php
* searchform.php

**Note: Cached and optimized/minified assets(JS/CSS) must be flushed/re-generated after the upgrade**

= 2.11.1 2025-12-16 =

**Enhancements**

* Added: 'Privacy Options' for Member Directory. 'Who can see this member directory' and 'Allowed Roles'.
* Added: 'Rate Limit' setting for nopriv AJAX actions.

**Bugfixes**

* Fixed: Security issue CVE ID: CVE-2025-13220. Used `shortcode_atts()` function to avoid using wrong attributes.
* Fixed: Security issue CVE ID: CVE-2025-13217. Implementing proper input sanitization and escaping for iframe URLs in YouTube, Vimeo, and Google Maps embeds.
* Fixed: Security issue CVE ID: CVE-2025-14081. Filtering fields based on user permissions during Account form submission.
* Fixed: Security issue CVE ID: CVE-2025-12492. Added directory privacy settings and added rate limiting.

**Templates Requiring Update**

* members.php
* members-grid.php
* members-list.php

= 2.11.0 2025-12-02 =

**Enhancements**

* Added: Extra condition for checking the license activation requests.
* Added: 2nd `$args` attribute to the action hook 'um_cover_area_content'.
* Added: `$args` and `$user_id` attributes to the action hook 'um_after_profile_header_name'.
* Added: Class `um-profile-subnav-{$subnav_id}-link` to the sub navigation links in the User Profile page.
* Tweak: Updated `Extensions_Updater` class to use Action Scheduler in the upgrade process of the UM extensions.

**Bugfixes**

* Fixed: User profile links in the comments section on the frontend when the `$comment->user_id` is empty.
* Fixed: The `emotize` function regexp for better emoji converting.
* Fixed: The conflict between the image uploader and lazy-loading attribute added by 3rd-party plugins.
* Fixed: PHP warnings for roles without meta data.
* Fixed: Typo in labels.

[See changelog for all versions](https://plugins.svn.wordpress.org/ultimate-member/trunk/changelog.txt).

== Upgrade Notice ==

= 2.11.3 =
This version fixes a security related bug. Upgrade immediately.

= 2.11.2 =
This version fixes a security related bug. Upgrade immediately.

= 2.11.1 =
This version fixes a security related bug. Upgrade immediately.

= 2.10.4 =
This version fixes a security related bug. Upgrade immediately.

= 2.10.2 =
This version fixes a security related bug. Upgrade immediately.

= 2.10.1 =
This version fixes a security related bug. Upgrade immediately.

= 2.10.0 =
Increased the minimum PHP and WordPress requirements. The plugin now requires at least PHP 7.0 and WordPress 6.2. This version fixes a security related bug. Upgrade immediately.

= 2.9.2 =
This version fixes a security related bug. Upgrade immediately.

= 2.9.0 =
This version fixes a security related bug. Upgrade immediately.

= 2.8.7 =
This version fixes a security related bug. Upgrade immediately.

= 2.8.5 =
This version fixes a security related bug. Upgrade immediately.

= 2.8.4 =
This version fixes a security related bug. Upgrade immediately.

= 2.8.3 =
This version fixes a security related bug. Upgrade immediately.

= 2.6.7 =
This version fixes a privilege escalation vulnerability used through UM Forms. Known in the wild that vulnerability allowed strangers to create administrator-level WordPress users. Please update immediately and check all administrator-level users on your website.

= 2.6.5 =
This version fixes a security related bug. Upgrade immediately. Version <= 2.6.4 has a privilege escalation vulnerability with administrator-level users.

= 2.6.4 =
This version fixes a security related bug. Upgrade immediately.
